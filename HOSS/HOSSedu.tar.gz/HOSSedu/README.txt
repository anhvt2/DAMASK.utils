Last updated on:  July 13, 2021


CONTENTS
--------
The HOSSedu downloadable package should include the following: 

1.) The 'HOSSedu' executable and 'HossMatLib' material library. (Two versions are included, see COMPILER for details.)
2.) The 'HOSSm' and 'HOSSd' mesh translators. (See User Manual for details.)
3.) Tutorials that include ready-to-run examples, and step-by-step descriptions.
4.) The HOSSedu User Manual.
5.) The licensing agreement, LICENSE.txt.


DESCRIPTION
-----------
This is the Hybrid Optimization Software Suite Educational Version (HOSSedu). 
HOSS software, developed at Los Alamos National Laboratory, 
is a powerful, flexible, and parallelized package that enables the user 
to predict deformation and failure of materials in a variety of situations.  
The HOSS educational version (HOSSedu) is a general purpose combined finite 
discrete element (FDEM) code that can be used to simulate problems involving 
fracture and fragmentation processes, large deformation and large rotations 
discrete particle systems. As such, the code will allow the users to run 
numerical models in parallel, but with limitations regarding the maximum 
number of processes and the maximum number of elements available. 
More information about HOSS can be found at hoss.lanl.gov


LICENSE
-------
HOSSedu is distributed under the terms of the License Agreement, LICENSE.txt.


COMPILER
--------
For convenience and better compatibility with native user environments, 
HOSSedu has been compiled with both openmpi and intel compilers, respectively: 

openmpi:
  openmpi/3.1.6   
  gcc (GCC) 4.8.5 20150623 (Red Hat 4.8.5-39)

intel:
  intel-mpi/5.0.3
  gcc (GCC) 4.8.5 20150623 (Red Hat 4.8.5-39)


SETUP
-----
HOSSedu usage on personal machine (Linux OS only): 

1.) Place HOSSedu executables 'HOSSedu' and 'HossMatLib' in directory of user's choice.
2.) Download either openmpi or intel-mpi. The version will depend on what the executable was compiled with (see above). 
3.) Create a module for openmpi or intel-mpi (again, in directory of user's choice):
    step 1: mkdir modulefiles
    step 2: open a blank text file and add the following (using openmpi as an example):
	    #%Module1.0
            
            set prefix /usr/lib/openmpi

            set bindir $prefix/bin;
            set mandir $prefix/share;
            set libdir $prefix/lib;

            prepend-path PATH              $bindir;
            prepend-path MANPATH           $mandir;
            prepend-path LD_LIBRARY_PATH   $libdir;

4.) Load the openmpi module.
5.) Execute HOSS with desired number of processors.

HOSSedu can be similarly setup in native HPC environments (Linux OS only).


TUTORIALS
---------
General information on how to get started with HOSSedu can be found in the HOSSedu User Manual.
Ready-to-run examples are provided in the tutorials folder, including: 

1.) A 2D elastic (FEM) disk experiencing an internal pressure.
2.) A 2D cohesive (FDEM) disk experiencing an internal pressure, and fracturing as a result.
3.) A 3D tri-axial direct shear experiment that is done in two stages. In the first stage a confining pressure is applied and the sample must be allowed to reach equilibrium. The second stage uses the <RESTART> context to directly shear the confined sample.
	

