function out = eq(g1,g2)

out = g1.id == g2.id;
