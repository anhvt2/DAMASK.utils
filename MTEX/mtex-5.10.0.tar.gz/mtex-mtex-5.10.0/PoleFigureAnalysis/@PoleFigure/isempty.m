function out = isempty(pf)
% overloads length

out = isempty(pf.intensities);
