function pf = uminus(pf)
% implements -pf

pf = (-1) .* pf;
