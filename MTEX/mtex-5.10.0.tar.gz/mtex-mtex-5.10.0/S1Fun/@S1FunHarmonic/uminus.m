function fun = uminus(fun)

fun.fhat = -fun.fhat;

end
