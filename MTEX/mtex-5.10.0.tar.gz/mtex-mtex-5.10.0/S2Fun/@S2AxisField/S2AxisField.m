classdef S2AxisField
% a class represeneting a axis field on the sphere

methods

  function AF = S2AxisField(varargin)
  end
  
end

end
