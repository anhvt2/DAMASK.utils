function sF = minus(sF1,sF2)
% overload minus
        
sF = plus(sF1,-sF2);
        
end
