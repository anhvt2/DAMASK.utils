function sF = ctranspose(sF)
% ctransposes S2FunHarmonic

sF = conj(sF.');

end
