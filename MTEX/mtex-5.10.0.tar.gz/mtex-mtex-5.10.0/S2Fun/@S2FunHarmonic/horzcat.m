function sF = horzcat(varargin)
%overloads horzcat

  sF = cat(2,varargin{:});

end
