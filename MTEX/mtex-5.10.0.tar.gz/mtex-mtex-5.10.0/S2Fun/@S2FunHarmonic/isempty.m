function out = isempty(S2F)
% overloads isempty

out = isempty(S2F.fhat);
