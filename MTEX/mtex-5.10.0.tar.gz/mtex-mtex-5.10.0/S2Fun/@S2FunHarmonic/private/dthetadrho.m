function sF = dthetadrho(sF)
% second derivative in direction theta and rho

sF = sF.dtheta.drho;

end
