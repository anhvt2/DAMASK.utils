function sF = subSet(sF,ind)
% subindex S2FunHarmonic

sF.fhat = sF.fhat(:, ind);

end
