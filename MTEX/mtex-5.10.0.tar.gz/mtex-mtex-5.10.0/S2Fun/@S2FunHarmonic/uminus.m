function sF = uminus(sF)
%
% Syntax
%   sF = -sF
%

sF.fhat = -sF.fhat;

end
