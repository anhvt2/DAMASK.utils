function sF = vertcat(varargin)
% overloads vertcat

sF = cat(1,varargin{:});

end
