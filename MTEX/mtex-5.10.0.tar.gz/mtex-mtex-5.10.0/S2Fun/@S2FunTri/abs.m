function sF = abs(sF)
              
sF.values = abs(sF.values);
    
end