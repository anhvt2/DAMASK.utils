function value = mean(sF1)
% mean value of a spherical function
%


value = mean(sF1.values(:));
    
end