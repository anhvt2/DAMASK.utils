function sF = rotate(sF, rot)
 
sF.tri = rotate(sF.tri,rot);
       
end