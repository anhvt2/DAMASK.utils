function sF = uminus(sF)
     
sF.values = -sF.values;
        
end