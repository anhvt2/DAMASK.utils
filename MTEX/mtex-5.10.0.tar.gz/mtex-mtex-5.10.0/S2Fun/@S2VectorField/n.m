function v = n(v)
%
% Gives the normal vector of the tangential plane in v
%

end
