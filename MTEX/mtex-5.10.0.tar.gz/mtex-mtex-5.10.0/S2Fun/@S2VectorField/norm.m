function norm(vF)

S2F = S2FunHandle(@(v) norm(vF.eval(v)));
