function SVF = normal
% the normal vector field
%


SVF = S2VectorFieldHandle(@(v) v);

end
