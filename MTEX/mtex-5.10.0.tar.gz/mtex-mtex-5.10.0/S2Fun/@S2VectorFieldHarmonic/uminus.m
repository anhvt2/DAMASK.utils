function sVF = uminus(sVF)
%
% Syntax
%   sVF = -sVF
%

sVF.sF = -sVF.sF;

end
