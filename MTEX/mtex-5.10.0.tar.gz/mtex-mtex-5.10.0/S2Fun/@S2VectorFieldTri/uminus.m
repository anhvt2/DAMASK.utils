function sVF = uminus(sVF)
%

sVF.values = -sVF.values;

end
