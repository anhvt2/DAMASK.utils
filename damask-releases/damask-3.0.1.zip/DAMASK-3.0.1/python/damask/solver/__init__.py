"""Run simulations directly from Python."""

from ._marc     import Marc       # noqa
