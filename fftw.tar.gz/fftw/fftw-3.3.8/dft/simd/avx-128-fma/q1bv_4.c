/* Generated automatically.  DO NOT EDIT! */
#define SIMD_HEADER "simd-support/simd-avx-128-fma.h"
#include "../common/q1bv_4.c"
