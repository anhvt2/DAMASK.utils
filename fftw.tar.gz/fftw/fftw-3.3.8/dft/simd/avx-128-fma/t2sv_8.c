/* Generated automatically.  DO NOT EDIT! */
#define SIMD_HEADER "simd-support/simd-avx-128-fma.h"
#include "../common/t2sv_8.c"
