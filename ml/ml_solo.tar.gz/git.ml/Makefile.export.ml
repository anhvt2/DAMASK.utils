###########################################################################
# These are the include path and the libraries needed to compile the ML
# library, and to link the ML library with another package of an
# application.
###########################################################################

# Optional ML dependencies 
#include /home/anhtran/data/petsc/petsc-3.9.4/arch-linux2-c-opt/externalpackages/git.ml/../galeri/Makefile.export.galeri
#include /home/anhtran/data/petsc/petsc-3.9.4/arch-linux2-c-opt/externalpackages/git.ml/../epetra/Makefile.export.epetra 
#include /home/anhtran/data/petsc/petsc-3.9.4/arch-linux2-c-opt/externalpackages/git.ml/../amesos/Makefile.export.amesos
#include /home/anhtran/data/petsc/petsc-3.9.4/arch-linux2-c-opt/externalpackages/git.ml/../ifpack/Makefile.export.ifpack
#include /home/anhtran/data/petsc/petsc-3.9.4/arch-linux2-c-opt/externalpackages/git.ml/../teuchos/Makefile.export.teuchos
#include /home/anhtran/data/petsc/petsc-3.9.4/arch-linux2-c-opt/externalpackages/git.ml/../aztecoo/Makefile.export.aztecoo
#include /home/anhtran/data/petsc/petsc-3.9.4/arch-linux2-c-opt/externalpackages/git.ml/../epetraext/Makefile.export.epetraext
#include /home/anhtran/data/petsc/petsc-3.9.4/arch-linux2-c-opt/externalpackages/git.ml/../isorropia/Makefile.export.isorropia

# These are the needed includes to build the library
_ML_BUILD_LIB_INCLUDES = \
	    -I/home/anhtran/data/petsc/petsc-3.9.4/arch-linux2-c-opt/externalpackages/git.ml/src \
	    -I/home/anhtran/data/petsc/petsc-3.9.4/arch-linux2-c-opt/externalpackages/git.ml/src \
            -I/home/anhtran/data/petsc/petsc-3.9.4/arch-linux2-c-opt/externalpackages/git.ml/src/Comm \
	    -I/home/anhtran/data/petsc/petsc-3.9.4/arch-linux2-c-opt/externalpackages/git.ml/src/Operator \
	    -I/home/anhtran/data/petsc/petsc-3.9.4/arch-linux2-c-opt/externalpackages/git.ml/src/Smoother \
	    -I/home/anhtran/data/petsc/petsc-3.9.4/arch-linux2-c-opt/externalpackages/git.ml/src/Coarsen \
	    -I/home/anhtran/data/petsc/petsc-3.9.4/arch-linux2-c-opt/externalpackages/git.ml/src/Krylov \
	    -I/home/anhtran/data/petsc/petsc-3.9.4/arch-linux2-c-opt/externalpackages/git.ml/src/Main \
	    -I/home/anhtran/data/petsc/petsc-3.9.4/arch-linux2-c-opt/externalpackages/git.ml/src/FEGrid \
	    -I/home/anhtran/data/petsc/petsc-3.9.4/arch-linux2-c-opt/externalpackages/git.ml/src/Utils \
	    -I/home/anhtran/data/petsc/petsc-3.9.4/arch-linux2-c-opt/externalpackages/git.ml/src/MLAPI \
	    -I/home/anhtran/data/petsc/petsc-3.9.4/arch-linux2-c-opt/externalpackages/git.ml/src/MatrixFree \
	    -I/home/anhtran/data/petsc/petsc-3.9.4/arch-linux2-c-opt/externalpackages/git.ml/src/Include \
	    $(ISORROPIA_INCLUDES) \
	    $(GALERI_INCLUDES) \
	    $(EPETRA_INCLUDES) \
	    $(AMESOS_INCLUDES) \
	    $(IFPACK_INCLUDES) \
	    $(TEUCHOS_INCLUDES) \
	    $(AZTECOO_INCLUDES) \
	    $(EPETRAEXT_INCLUDES)

# These are the needed includes to build the examples
_ML_INCLUDES = \
	    -I/home/anhtran/data/petsc/petsc-3.9.4/arch-linux2-c-opt/externalpackages/git.ml/src \
	    -I/home/anhtran/data/petsc/petsc-3.9.4/arch-linux2-c-opt/externalpackages/git.ml/src \
            -I/home/anhtran/data/petsc/petsc-3.9.4/arch-linux2-c-opt/externalpackages/git.ml/src/Comm \
	    -I/home/anhtran/data/petsc/petsc-3.9.4/arch-linux2-c-opt/externalpackages/git.ml/src/Operator \
	    -I/home/anhtran/data/petsc/petsc-3.9.4/arch-linux2-c-opt/externalpackages/git.ml/src/Smoother \
	    -I/home/anhtran/data/petsc/petsc-3.9.4/arch-linux2-c-opt/externalpackages/git.ml/src/Coarsen \
	    -I/home/anhtran/data/petsc/petsc-3.9.4/arch-linux2-c-opt/externalpackages/git.ml/src/Krylov \
	    -I/home/anhtran/data/petsc/petsc-3.9.4/arch-linux2-c-opt/externalpackages/git.ml/src/Main \
	    -I/home/anhtran/data/petsc/petsc-3.9.4/arch-linux2-c-opt/externalpackages/git.ml/src/FEGrid \
	    -I/home/anhtran/data/petsc/petsc-3.9.4/arch-linux2-c-opt/externalpackages/git.ml/src/Utils \
	    -I/home/anhtran/data/petsc/petsc-3.9.4/arch-linux2-c-opt/externalpackages/git.ml/src/MLAPI \
	    -I/home/anhtran/data/petsc/petsc-3.9.4/arch-linux2-c-opt/externalpackages/git.ml/src/MatrixFree \
	    -I/home/anhtran/data/petsc/petsc-3.9.4/arch-linux2-c-opt/externalpackages/git.ml/src/RefMaxwell \
	    -I/home/anhtran/data/petsc/petsc-3.9.4/arch-linux2-c-opt/externalpackages/git.ml/src/Include \
	    $(ISORROPIA_INCLUDES) \
	    $(GALERI_INCLUDES) \
	    $(EPETRA_INCLUDES) \
	    $(AMESOS_INCLUDES) \
	    $(IFPACK_INCLUDES) \
	    $(TEUCHOS_INCLUDES) \
	    $(AZTECOO_INCLUDES) \
	    $(EPETRAEXT_INCLUDES)

_ML_LIBS =  -L/home/anhtran/data/petsc/petsc-3.9.4/arch-linux2-c-opt/externalpackages/git.ml/src -lml $(GALERI_LIBS) $(ISORROPIA_LIBS) $(EPETRA_LIBS) $(AMESOS_LIBS) $(IFPACK_LIBS) $(TEUCHOS_LIBS) $(AZTECOO_LIBS) $(EPETRAEXT_LIBS)  -Wl,-rpath,/ascldap/users/anhtran/local/petsc-3.9.4/lib -L/ascldap/users/anhtran/local/petsc-3.9.4/lib -lflapack -Wl,-rpath,/ascldap/users/anhtran/local/petsc-3.9.4/lib -L/ascldap/users/anhtran/local/petsc-3.9.4/lib -lfblas -lm -lstdc++ -ldl -Wl,-rpath,/ascldap/users/anhtran/local/petsc-3.9.4/lib -L/ascldap/users/anhtran/local/petsc-3.9.4/lib -lmpifort -lmpi -lgfortran -lm -Wl,-rpath,/opt/rh/devtoolset-7/root/usr/lib/gcc/x86_64-redhat-linux/7 -L/opt/rh/devtoolset-7/root/usr/lib/gcc/x86_64-redhat-linux/7 -Wl,-rpath,/opt/rh/devtoolset-7/root/usr/lib64 -L/opt/rh/devtoolset-7/root/usr/lib64 -Wl,-rpath,/opt/rh/devtoolset-7/root/usr/lib -L/opt/rh/devtoolset-7/root/usr/lib -Wl,-rpath,/ascldap/users/anhtran/local/petsc-3.9.4/lib -lgfortran -lm -lgcc_s -lquadmath   -L/ascldap/users/anhtran/local/petsc-3.9.4/lib -L/opt/rh/devtoolset-7/root/usr/lib/gcc/x86_64-redhat-linux/7 -L/opt/rh/devtoolset-7/root/usr/lib/gcc/x86_64-redhat-linux/7/../../../../lib64 -L/lib/../lib64 -L/usr/lib/../lib64 -L/opt/rh/devtoolset-7/root/usr/lib/gcc/x86_64-redhat-linux/7/../../.. -lmpifort -lmpi -lgfortran -lm -lquadmath 

#ML_BUILD_LIB_INCLUDES  = $(shell perl /home/anhtran/data/petsc/petsc-3.9.4/arch-linux2-c-opt/externalpackages/git.ml/config/strip_dup_incl_paths.pl $(_ML_BUILD_LIB_INCLUDES))
#ML_INCLUDES  = $(shell perl /home/anhtran/data/petsc/petsc-3.9.4/arch-linux2-c-opt/externalpackages/git.ml/config/strip_dup_incl_paths.pl $(_ML_INCLUDES))
#ML_LIBS      = $(shell perl /home/anhtran/data/petsc/petsc-3.9.4/arch-linux2-c-opt/externalpackages/git.ml/config/strip_dup_libs.pl $(_ML_LIBS))
ML_BUILD_LIB_INCLUDES = $(_ML_BUILD_LIB_INCLUDES)
ML_INCLUDES = $(_ML_INCLUDES)
ML_LIBS     = $(_ML_LIBS)

###########################################################################
# These variables define the include path and libraries that can be used in
# ML's examples and tests, but that are not required to compile or link
# ML itself.
###########################################################################

#Currently no packages are listed in this area.  Galeri is now used in
# ml/src.

##include /home/anhtran/data/petsc/petsc-3.9.4/arch-linux2-c-opt/externalpackages/git.ml/../galeri/Makefile.export.galeri

_ML_EXTRA_INCLUDES =

_ML_EXTRA_LIBS =

#ML_EXTRA_INCLUDES  = $(shell perl /home/anhtran/data/petsc/petsc-3.9.4/arch-linux2-c-opt/externalpackages/git.ml/config/strip_dup_incl_paths.pl $(_ML_EXTRA_INCLUDES))
#ML_EXTRA_LIBS      = $(shell perl /home/anhtran/data/petsc/petsc-3.9.4/arch-linux2-c-opt/externalpackages/git.ml/config/strip_dup_libs.pl $(_ML_EXTRA_LIBS))
ML_EXTRA_INCLUDES = $(_ML_EXTRA_INCLUDES)
ML_EXTRA_LIBS     = $(_ML_EXTRA_LIBS)

#ML_LINK = $(CXX) $(AM_CFLAGS) $(CFLAGS) $(AM_LDFLAGS) $(LDFLAGS) -o $@
ML_LINK = $(CXX) $(AM_LDFLAGS) $(LDFLAGS) -o $@

# Macro that can be added to a user's Makefile as a dependency to ensure
# relinking if the ML library changes.
ML_LIB_DEP = /home/anhtran/data/petsc/petsc-3.9.4/arch-linux2-c-opt/externalpackages/git.ml/src/libml.a
