#include "petsc.h"
#include "petscfix.h"
/* random.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "petscsys.h"
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscrandomdestroy_ PETSCRANDOMDESTROY
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscrandomdestroy_ petscrandomdestroy
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscrandomcreate_ PETSCRANDOMCREATE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscrandomcreate_ petscrandomcreate
#endif
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscrandomgetvalue_ PETSCRANDOMGETVALUE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscrandomgetvalue_ petscrandomgetvalue
#endif


/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL   petscrandomdestroy_(PetscRandom r, int *__ierr ){
*__ierr = PetscRandomDestroy(
	(PetscRandom)PetscToPointer((r) ));
}
void PETSC_STDCALL   petscrandomcreate_(MPI_Fint * comm,PetscRandomType *type,PetscRandom *r, int *__ierr ){
*__ierr = PetscRandomCreate(
	MPI_Comm_f2c( *(comm) ),*type,r);
}
void PETSC_STDCALL   petscrandomgetvalue_(PetscRandom r,PetscScalar *val, int *__ierr ){
*__ierr = PetscRandomGetValue(
	(PetscRandom)PetscToPointer((r) ),val);
}
#if defined(__cplusplus)
}
#endif
