!
!
!  Include file for Fortran use of the Mesh package in PETSc
!
#if !defined (__PETSCMESH_H)
#define __PETSCMESH_H

#define Mesh PetscFortranAddr
#define MeshType character*(80)

#define MESHSIEVE 'sieve'

#endif
