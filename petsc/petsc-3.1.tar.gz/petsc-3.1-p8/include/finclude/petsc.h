!
!  Single Fortran include file for all of PETSc
!

#include "finclude/petscsys.h"
#include "finclude/petscdraw.h"
#include "finclude/petscviewer.h"
#include "finclude/petscis.h"
#include "finclude/petscvec.h"
#include "finclude/petscmat.h"
#include "finclude/petscpc.h"
#include "finclude/petscksp.h"
#include "finclude/petscsnes.h"
#include "finclude/petscda.h"
#include "finclude/petscmesh.h"
