#if !defined(PETSCHIPBLAS_H)
#define PETSCHIPBLAS_H

#warning "petschipblas.h is deprecated, use petscdevice.h instead"

#include <petscdevice.h>

#endif /* PETSCHIPBLAS_H */
