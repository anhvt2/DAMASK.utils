all = ['f2cblaslapack','BlasLapack', 'CHOLMOD', 'exodusii', 'scientificpython', 'fiat', 'MOAB', 'MPI', 'netcdf', 'PETSc', 'UMFPACK', 'boost', 'cusp', 'thrust', 'hdf5', 'netcdf-cxx']
