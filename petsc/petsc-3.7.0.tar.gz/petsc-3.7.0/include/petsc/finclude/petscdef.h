!
!  Single Fortran include file for all of PETSc
!

#include "petsc/finclude/petscsysdef.h"
#include "petsc/finclude/petscdrawdef.h"
#include "petsc/finclude/petscviewerdef.h"
#include "petsc/finclude/petscbagdef.h"
#include "petsc/finclude/petscisdef.h"
#include "petsc/finclude/petscvecdef.h"
#include "petsc/finclude/petscmatdef.h"
#include "petsc/finclude/petscdmdef.h"
#include "petsc/finclude/petscdmdadef.h"
#include "petsc/finclude/petscdmplexdef.h"
#include "petsc/finclude/petscpcdef.h"
#include "petsc/finclude/petsckspdef.h"
#include "petsc/finclude/petscsnesdef.h"
#include "petsc/finclude/petsctsdef.h"
