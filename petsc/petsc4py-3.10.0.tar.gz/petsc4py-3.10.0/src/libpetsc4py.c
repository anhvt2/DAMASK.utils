#define MPICH_SKIP_MPICXX 1
#define OMPI_SKIP_MPICXX 1
#include <Python.h>
#include <petsc.h>
#include "libpetsc4py/libpetsc4py.c"
