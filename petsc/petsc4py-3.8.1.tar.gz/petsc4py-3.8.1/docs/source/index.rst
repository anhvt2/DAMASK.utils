================
PETSc for Python
================

:Author:       Lisandro Dalcin
:Contact:      dalcinl@gmail.com
:Web Site:     https://bitbucket.org/petsc/petsc4py
:Date:         |today|

.. include:: abstract.txt

Contents
========

.. include:: toctree.txt

.. include:: links.txt
