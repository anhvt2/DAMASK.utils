/* ao.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "petscfix.h"
#include "petscao.h"
#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define aodestroy_ PAODESTROY
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define aodestroy_ paodestroy
#else
#define aodestroy_ paodestroy_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define aodestroy_ AODESTROY
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define aodestroy_ aodestroy
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define aopetsctoapplicationis_ PAOPETSCTOAPPLICATIONIS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define aopetsctoapplicationis_ paopetsctoapplicationis
#else
#define aopetsctoapplicationis_ paopetsctoapplicationis_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define aopetsctoapplicationis_ AOPETSCTOAPPLICATIONIS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define aopetsctoapplicationis_ aopetsctoapplicationis
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define aoapplicationtopetscis_ PAOAPPLICATIONTOPETSCIS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define aoapplicationtopetscis_ paoapplicationtopetscis
#else
#define aoapplicationtopetscis_ paoapplicationtopetscis_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define aoapplicationtopetscis_ AOAPPLICATIONTOPETSCIS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define aoapplicationtopetscis_ aoapplicationtopetscis
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define aopetsctoapplication_ PAOPETSCTOAPPLICATION
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define aopetsctoapplication_ paopetsctoapplication
#else
#define aopetsctoapplication_ paopetsctoapplication_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define aopetsctoapplication_ AOPETSCTOAPPLICATION
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define aopetsctoapplication_ aopetsctoapplication
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define aoapplicationtopetsc_ PAOAPPLICATIONTOPETSC
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define aoapplicationtopetsc_ paoapplicationtopetsc
#else
#define aoapplicationtopetsc_ paoapplicationtopetsc_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define aoapplicationtopetsc_ AOAPPLICATIONTOPETSC
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define aoapplicationtopetsc_ aoapplicationtopetsc
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define aopetsctoapplicationpermuteint_ PAOPETSCTOAPPLICATIONPERMUTEINT
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define aopetsctoapplicationpermuteint_ paopetsctoapplicationpermuteint
#else
#define aopetsctoapplicationpermuteint_ paopetsctoapplicationpermuteint_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define aopetsctoapplicationpermuteint_ AOPETSCTOAPPLICATIONPERMUTEINT
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define aopetsctoapplicationpermuteint_ aopetsctoapplicationpermuteint
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define aoapplicationtopetscpermuteint_ PAOAPPLICATIONTOPETSCPERMUTEINT
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define aoapplicationtopetscpermuteint_ paoapplicationtopetscpermuteint
#else
#define aoapplicationtopetscpermuteint_ paoapplicationtopetscpermuteint_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define aoapplicationtopetscpermuteint_ AOAPPLICATIONTOPETSCPERMUTEINT
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define aoapplicationtopetscpermuteint_ aoapplicationtopetscpermuteint
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define aopetsctoapplicationpermutereal_ PAOPETSCTOAPPLICATIONPERMUTEREAL
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define aopetsctoapplicationpermutereal_ paopetsctoapplicationpermutereal
#else
#define aopetsctoapplicationpermutereal_ paopetsctoapplicationpermutereal_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define aopetsctoapplicationpermutereal_ AOPETSCTOAPPLICATIONPERMUTEREAL
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define aopetsctoapplicationpermutereal_ aopetsctoapplicationpermutereal
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define aoapplicationtopetscpermutereal_ PAOAPPLICATIONTOPETSCPERMUTEREAL
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define aoapplicationtopetscpermutereal_ paoapplicationtopetscpermutereal
#else
#define aoapplicationtopetscpermutereal_ paoapplicationtopetscpermutereal_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define aoapplicationtopetscpermutereal_ AOAPPLICATIONTOPETSCPERMUTEREAL
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define aoapplicationtopetscpermutereal_ aoapplicationtopetscpermutereal
#endif
#endif



/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL  aodestroy_(AO ao, int *ierr ){
*ierr = AODestroy(
	(AO)PetscToPointer( (ao) ));
}
void PETSC_STDCALL  aopetsctoapplicationis_(AO ao,IS is, int *ierr ){
*ierr = AOPetscToApplicationIS(
	(AO)PetscToPointer( (ao) ),
	(IS)PetscToPointer( (is) ));
}
void PETSC_STDCALL  aoapplicationtopetscis_(AO ao,IS is, int *ierr ){
*ierr = AOApplicationToPetscIS(
	(AO)PetscToPointer( (ao) ),
	(IS)PetscToPointer( (is) ));
}
void PETSC_STDCALL  aopetsctoapplication_(AO ao,PetscInt *n,PetscInt ia[], int *ierr ){
*ierr = AOPetscToApplication(
	(AO)PetscToPointer( (ao) ),*n,ia);
}
void PETSC_STDCALL  aoapplicationtopetsc_(AO ao,PetscInt *n,PetscInt ia[], int *ierr ){
*ierr = AOApplicationToPetsc(
	(AO)PetscToPointer( (ao) ),*n,ia);
}
void PETSC_STDCALL  aopetsctoapplicationpermuteint_(AO ao,PetscInt *block,PetscInt array[], int *ierr ){
*ierr = AOPetscToApplicationPermuteInt(
	(AO)PetscToPointer( (ao) ),*block,array);
}
void PETSC_STDCALL  aoapplicationtopetscpermuteint_(AO ao,PetscInt *block,PetscInt array[], int *ierr ){
*ierr = AOApplicationToPetscPermuteInt(
	(AO)PetscToPointer( (ao) ),*block,array);
}
void PETSC_STDCALL  aopetsctoapplicationpermutereal_(AO ao,PetscInt *block,PetscReal array[], int *ierr ){
*ierr = AOPetscToApplicationPermuteReal(
	(AO)PetscToPointer( (ao) ),*block,array);
}
void PETSC_STDCALL  aoapplicationtopetscpermutereal_(AO ao,PetscInt *block,PetscReal array[], int *ierr ){
*ierr = AOApplicationToPetscPermuteReal(
	(AO)PetscToPointer( (ao) ),*block,array);
}
#if defined(__cplusplus)
}
#endif
