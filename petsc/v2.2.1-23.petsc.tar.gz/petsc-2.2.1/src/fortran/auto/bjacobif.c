/* bjacobi.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "petscfix.h"
#include "petscpc.h"
#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pcbjacobisetusetruelocal_ PPCBJACOBISETUSETRUELOCAL
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pcbjacobisetusetruelocal_ ppcbjacobisetusetruelocal
#else
#define pcbjacobisetusetruelocal_ ppcbjacobisetusetruelocal_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pcbjacobisetusetruelocal_ PCBJACOBISETUSETRUELOCAL
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pcbjacobisetusetruelocal_ pcbjacobisetusetruelocal
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pcbjacobisettotalblocks_ PPCBJACOBISETTOTALBLOCKS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pcbjacobisettotalblocks_ ppcbjacobisettotalblocks
#else
#define pcbjacobisettotalblocks_ ppcbjacobisettotalblocks_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pcbjacobisettotalblocks_ PCBJACOBISETTOTALBLOCKS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pcbjacobisettotalblocks_ pcbjacobisettotalblocks
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pcbjacobisetlocalblocks_ PPCBJACOBISETLOCALBLOCKS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pcbjacobisetlocalblocks_ ppcbjacobisetlocalblocks
#else
#define pcbjacobisetlocalblocks_ ppcbjacobisetlocalblocks_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pcbjacobisetlocalblocks_ PCBJACOBISETLOCALBLOCKS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pcbjacobisetlocalblocks_ pcbjacobisetlocalblocks
#endif
#endif



/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL  pcbjacobisetusetruelocal_(PC pc, int *ierr ){
*ierr = PCBJacobiSetUseTrueLocal(
	(PC)PetscToPointer( (pc) ));
}
void PETSC_STDCALL  pcbjacobisettotalblocks_(PC pc,PetscInt *blocks, PetscInt lens[], int *ierr ){
*ierr = PCBJacobiSetTotalBlocks(
	(PC)PetscToPointer( (pc) ),*blocks,lens);
}
void PETSC_STDCALL  pcbjacobisetlocalblocks_(PC pc,PetscInt *blocks, PetscInt lens[], int *ierr ){
*ierr = PCBJacobiSetLocalBlocks(
	(PC)PetscToPointer( (pc) ),*blocks,lens);
}
#if defined(__cplusplus)
}
#endif
