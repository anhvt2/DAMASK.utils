/* dmouse.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "petscfix.h"
#include "petscdraw.h"
#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawgetmousebutton_ PPETSCDRAWGETMOUSEBUTTON
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawgetmousebutton_ ppetscdrawgetmousebutton
#else
#define petscdrawgetmousebutton_ ppetscdrawgetmousebutton_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawgetmousebutton_ PETSCDRAWGETMOUSEBUTTON
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawgetmousebutton_ petscdrawgetmousebutton
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawsynchronizedgetmousebutton_ PPETSCDRAWSYNCHRONIZEDGETMOUSEBUTTON
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawsynchronizedgetmousebutton_ ppetscdrawsynchronizedgetmousebutton
#else
#define petscdrawsynchronizedgetmousebutton_ ppetscdrawsynchronizedgetmousebutton_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawsynchronizedgetmousebutton_ PETSCDRAWSYNCHRONIZEDGETMOUSEBUTTON
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawsynchronizedgetmousebutton_ petscdrawsynchronizedgetmousebutton
#endif
#endif



/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL  petscdrawgetmousebutton_(PetscDraw *draw,PetscDrawButton *button,PetscReal* x_user,PetscReal *y_user,PetscReal *x_phys,PetscReal *y_phys, int *ierr ){
*ierr = PetscDrawGetMouseButton(*draw,
	(PetscDrawButton* )PetscToPointer( (button) ),x_user,y_user,x_phys,y_phys);
}
void PETSC_STDCALL  petscdrawsynchronizedgetmousebutton_(PetscDraw *draw,PetscDrawButton *button,PetscReal* x_user,PetscReal *y_user,PetscReal *x_phys,PetscReal *y_phys, int *ierr ){
*ierr = PetscDrawSynchronizedGetMouseButton(*draw,
	(PetscDrawButton* )PetscToPointer( (button) ),x_user,y_user,x_phys,y_phys);
}
#if defined(__cplusplus)
}
#endif
