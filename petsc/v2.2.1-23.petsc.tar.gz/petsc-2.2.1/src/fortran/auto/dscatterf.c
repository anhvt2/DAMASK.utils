/* dscatter.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "petscfix.h"
#include "petsc.h"
#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawspsetdimension_ PPETSCDRAWSPSETDIMENSION
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawspsetdimension_ ppetscdrawspsetdimension
#else
#define petscdrawspsetdimension_ ppetscdrawspsetdimension_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawspsetdimension_ PETSCDRAWSPSETDIMENSION
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawspsetdimension_ petscdrawspsetdimension
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawspreset_ PPETSCDRAWSPRESET
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawspreset_ ppetscdrawspreset
#else
#define petscdrawspreset_ ppetscdrawspreset_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawspreset_ PETSCDRAWSPRESET
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawspreset_ petscdrawspreset
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawspaddpoint_ PPETSCDRAWSPADDPOINT
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawspaddpoint_ ppetscdrawspaddpoint
#else
#define petscdrawspaddpoint_ ppetscdrawspaddpoint_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawspaddpoint_ PETSCDRAWSPADDPOINT
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawspaddpoint_ petscdrawspaddpoint
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawspdraw_ PPETSCDRAWSPDRAW
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawspdraw_ ppetscdrawspdraw
#else
#define petscdrawspdraw_ ppetscdrawspdraw_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawspdraw_ PETSCDRAWSPDRAW
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawspdraw_ petscdrawspdraw
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawspsetlimits_ PPETSCDRAWSPSETLIMITS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawspsetlimits_ ppetscdrawspsetlimits
#else
#define petscdrawspsetlimits_ ppetscdrawspsetlimits_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawspsetlimits_ PETSCDRAWSPSETLIMITS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawspsetlimits_ petscdrawspsetlimits
#endif
#endif



/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL  petscdrawspsetdimension_(PetscDrawSP *sp,int *dim, int *ierr ){
*ierr = PetscDrawSPSetDimension(*sp,*dim);
}
void PETSC_STDCALL  petscdrawspreset_(PetscDrawSP *sp, int *ierr ){
*ierr = PetscDrawSPReset(*sp);
}
void PETSC_STDCALL  petscdrawspaddpoint_(PetscDrawSP *sp,PetscReal *x,PetscReal *y, int *ierr ){
*ierr = PetscDrawSPAddPoint(*sp,x,y);
}
void PETSC_STDCALL  petscdrawspdraw_(PetscDrawSP *sp, int *ierr ){
*ierr = PetscDrawSPDraw(*sp);
}
void PETSC_STDCALL  petscdrawspsetlimits_(PetscDrawSP *sp,PetscReal *x_min,PetscReal *x_max,PetscReal *y_min,PetscReal *y_max, int *ierr ){
*ierr = PetscDrawSPSetLimits(*sp,*x_min,*x_max,*y_min,*y_max);
}
#if defined(__cplusplus)
}
#endif
