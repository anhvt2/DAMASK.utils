/* dtri.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "petscfix.h"
#include "petscdraw.h"
#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawtriangle_ PPETSCDRAWTRIANGLE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawtriangle_ ppetscdrawtriangle
#else
#define petscdrawtriangle_ ppetscdrawtriangle_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawtriangle_ PETSCDRAWTRIANGLE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawtriangle_ petscdrawtriangle
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawscalepopup_ PPETSCDRAWSCALEPOPUP
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawscalepopup_ ppetscdrawscalepopup
#else
#define petscdrawscalepopup_ ppetscdrawscalepopup_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawscalepopup_ PETSCDRAWSCALEPOPUP
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawscalepopup_ petscdrawscalepopup
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawtensorcontourpatch_ PPETSCDRAWTENSORCONTOURPATCH
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawtensorcontourpatch_ ppetscdrawtensorcontourpatch
#else
#define petscdrawtensorcontourpatch_ ppetscdrawtensorcontourpatch_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawtensorcontourpatch_ PETSCDRAWTENSORCONTOURPATCH
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawtensorcontourpatch_ petscdrawtensorcontourpatch
#endif
#endif



/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL  petscdrawtriangle_(PetscDraw *draw,PetscReal *x1,PetscReal *y_1,PetscReal *x2,PetscReal *y2,PetscReal *x3,PetscReal *y3,
                 int *c1,int *c2,int *c3, int *ierr ){
*ierr = PetscDrawTriangle(*draw,*x1,*y_1,*x2,*y2,*x3,*y3,*c1,*c2,*c3);
}
void PETSC_STDCALL  petscdrawscalepopup_(PetscDraw *popup,PetscReal *min,PetscReal *max, int *ierr ){
*ierr = PetscDrawScalePopup(*popup,*min,*max);
}
void PETSC_STDCALL  petscdrawtensorcontourpatch_(PetscDraw *draw,int *m,int *n,PetscReal *x,PetscReal *y,PetscReal *max,PetscReal *min,PetscReal *v, int *ierr ){
*ierr = PetscDrawTensorContourPatch(*draw,*m,*n,x,y,*max,*min,v);
}
#if defined(__cplusplus)
}
#endif
