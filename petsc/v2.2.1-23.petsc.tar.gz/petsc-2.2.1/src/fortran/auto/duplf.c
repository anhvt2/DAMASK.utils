/* dupl.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "petscfix.h"
#include "petscviewer.h"
#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscviewergetsingleton_ PPETSCVIEWERGETSINGLETON
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscviewergetsingleton_ ppetscviewergetsingleton
#else
#define petscviewergetsingleton_ ppetscviewergetsingleton_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscviewergetsingleton_ PETSCVIEWERGETSINGLETON
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscviewergetsingleton_ petscviewergetsingleton
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscviewerrestoresingleton_ PPETSCVIEWERRESTORESINGLETON
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscviewerrestoresingleton_ ppetscviewerrestoresingleton
#else
#define petscviewerrestoresingleton_ ppetscviewerrestoresingleton_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscviewerrestoresingleton_ PETSCVIEWERRESTORESINGLETON
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscviewerrestoresingleton_ petscviewerrestoresingleton
#endif
#endif



/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL  petscviewergetsingleton_(PetscViewer *viewer,PetscViewer *outviewer, int *ierr ){
*ierr = PetscViewerGetSingleton(*viewer,
	(PetscViewer* )PetscToPointer( (outviewer) ));
}
void PETSC_STDCALL  petscviewerrestoresingleton_(PetscViewer *viewer,PetscViewer *outviewer, int *ierr ){
*ierr = PetscViewerRestoreSingleton(*viewer,
	(PetscViewer* )PetscToPointer( (outviewer) ));
}
#if defined(__cplusplus)
}
#endif
