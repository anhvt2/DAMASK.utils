/* fdmatrix.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "petscfix.h"
#include "petscmat.h"
#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matfdcoloringsetparameters_ PMATFDCOLORINGSETPARAMETERS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matfdcoloringsetparameters_ pmatfdcoloringsetparameters
#else
#define matfdcoloringsetparameters_ pmatfdcoloringsetparameters_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matfdcoloringsetparameters_ MATFDCOLORINGSETPARAMETERS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matfdcoloringsetparameters_ matfdcoloringsetparameters
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matfdcoloringsetfrequency_ PMATFDCOLORINGSETFREQUENCY
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matfdcoloringsetfrequency_ pmatfdcoloringsetfrequency
#else
#define matfdcoloringsetfrequency_ pmatfdcoloringsetfrequency_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matfdcoloringsetfrequency_ MATFDCOLORINGSETFREQUENCY
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matfdcoloringsetfrequency_ matfdcoloringsetfrequency
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matfdcoloringgetfrequency_ PMATFDCOLORINGGETFREQUENCY
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matfdcoloringgetfrequency_ pmatfdcoloringgetfrequency
#else
#define matfdcoloringgetfrequency_ pmatfdcoloringgetfrequency_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matfdcoloringgetfrequency_ MATFDCOLORINGGETFREQUENCY
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matfdcoloringgetfrequency_ matfdcoloringgetfrequency
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matfdcoloringsetfromoptions_ PMATFDCOLORINGSETFROMOPTIONS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matfdcoloringsetfromoptions_ pmatfdcoloringsetfromoptions
#else
#define matfdcoloringsetfromoptions_ pmatfdcoloringsetfromoptions_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matfdcoloringsetfromoptions_ MATFDCOLORINGSETFROMOPTIONS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matfdcoloringsetfromoptions_ matfdcoloringsetfromoptions
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matfdcoloringapply_ PMATFDCOLORINGAPPLY
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matfdcoloringapply_ pmatfdcoloringapply
#else
#define matfdcoloringapply_ pmatfdcoloringapply_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matfdcoloringapply_ MATFDCOLORINGAPPLY
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matfdcoloringapply_ matfdcoloringapply
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matfdcoloringapplyts_ PMATFDCOLORINGAPPLYTS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matfdcoloringapplyts_ pmatfdcoloringapplyts
#else
#define matfdcoloringapplyts_ pmatfdcoloringapplyts_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matfdcoloringapplyts_ MATFDCOLORINGAPPLYTS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matfdcoloringapplyts_ matfdcoloringapplyts
#endif
#endif



/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL  matfdcoloringsetparameters_(MatFDColoring *matfd,PetscReal *error,PetscReal *umin, int *ierr ){
*ierr = MatFDColoringSetParameters(*matfd,*error,*umin);
}
void PETSC_STDCALL  matfdcoloringsetfrequency_(MatFDColoring *matfd,PetscInt *freq, int *ierr ){
*ierr = MatFDColoringSetFrequency(*matfd,*freq);
}
void PETSC_STDCALL  matfdcoloringgetfrequency_(MatFDColoring *matfd,PetscInt *freq, int *ierr ){
*ierr = MatFDColoringGetFrequency(*matfd,freq);
}
void PETSC_STDCALL  matfdcoloringsetfromoptions_(MatFDColoring *matfd, int *ierr ){
*ierr = MatFDColoringSetFromOptions(*matfd);
}
void PETSC_STDCALL  matfdcoloringapply_(Mat J,MatFDColoring *coloring,Vec x1,MatStructure *flag,void*sctx, int *ierr ){
*ierr = MatFDColoringApply(
	(Mat)PetscToPointer( (J) ),*coloring,
	(Vec)PetscToPointer( (x1) ),
	(MatStructure* )PetscToPointer( (flag) ),sctx);
}
void PETSC_STDCALL  matfdcoloringapplyts_(Mat J,MatFDColoring *coloring,PetscReal *t,Vec x1,MatStructure *flag,void*sctx, int *ierr ){
*ierr = MatFDColoringApplyTS(
	(Mat)PetscToPointer( (J) ),*coloring,*t,
	(Vec)PetscToPointer( (x1) ),
	(MatStructure* )PetscToPointer( (flag) ),sctx);
}
#if defined(__cplusplus)
}
#endif
