/* lg.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "petscfix.h"
#include "petsc.h"
#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawlgsetdimension_ PPETSCDRAWLGSETDIMENSION
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawlgsetdimension_ ppetscdrawlgsetdimension
#else
#define petscdrawlgsetdimension_ ppetscdrawlgsetdimension_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawlgsetdimension_ PETSCDRAWLGSETDIMENSION
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawlgsetdimension_ petscdrawlgsetdimension
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawlgreset_ PPETSCDRAWLGRESET
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawlgreset_ ppetscdrawlgreset
#else
#define petscdrawlgreset_ ppetscdrawlgreset_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawlgreset_ PETSCDRAWLGRESET
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawlgreset_ petscdrawlgreset
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawlgaddpoint_ PPETSCDRAWLGADDPOINT
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawlgaddpoint_ ppetscdrawlgaddpoint
#else
#define petscdrawlgaddpoint_ ppetscdrawlgaddpoint_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawlgaddpoint_ PETSCDRAWLGADDPOINT
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawlgaddpoint_ petscdrawlgaddpoint
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawlgindicatedatapoints_ PPETSCDRAWLGINDICATEDATAPOINTS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawlgindicatedatapoints_ ppetscdrawlgindicatedatapoints
#else
#define petscdrawlgindicatedatapoints_ ppetscdrawlgindicatedatapoints_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawlgindicatedatapoints_ PETSCDRAWLGINDICATEDATAPOINTS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawlgindicatedatapoints_ petscdrawlgindicatedatapoints
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawlgdraw_ PPETSCDRAWLGDRAW
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawlgdraw_ ppetscdrawlgdraw
#else
#define petscdrawlgdraw_ ppetscdrawlgdraw_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawlgdraw_ PETSCDRAWLGDRAW
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawlgdraw_ petscdrawlgdraw
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawlgprint_ PPETSCDRAWLGPRINT
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawlgprint_ ppetscdrawlgprint
#else
#define petscdrawlgprint_ ppetscdrawlgprint_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawlgprint_ PETSCDRAWLGPRINT
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawlgprint_ petscdrawlgprint
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawlgsetlimits_ PPETSCDRAWLGSETLIMITS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawlgsetlimits_ ppetscdrawlgsetlimits
#else
#define petscdrawlgsetlimits_ ppetscdrawlgsetlimits_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawlgsetlimits_ PETSCDRAWLGSETLIMITS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawlgsetlimits_ petscdrawlgsetlimits
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawlgspdraw_ PPETSCDRAWLGSPDRAW
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawlgspdraw_ ppetscdrawlgspdraw
#else
#define petscdrawlgspdraw_ ppetscdrawlgspdraw_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawlgspdraw_ PETSCDRAWLGSPDRAW
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawlgspdraw_ petscdrawlgspdraw
#endif
#endif



/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL  petscdrawlgsetdimension_(PetscDrawLG *lg,int *dim, int *ierr ){
*ierr = PetscDrawLGSetDimension(*lg,*dim);
}
void PETSC_STDCALL  petscdrawlgreset_(PetscDrawLG *lg, int *ierr ){
*ierr = PetscDrawLGReset(*lg);
}
void PETSC_STDCALL  petscdrawlgaddpoint_(PetscDrawLG *lg,PetscReal *x,PetscReal *y, int *ierr ){
*ierr = PetscDrawLGAddPoint(*lg,x,y);
}
void PETSC_STDCALL  petscdrawlgindicatedatapoints_(PetscDrawLG *lg, int *ierr ){
*ierr = PetscDrawLGIndicateDataPoints(*lg);
}
void PETSC_STDCALL  petscdrawlgdraw_(PetscDrawLG *lg, int *ierr ){
*ierr = PetscDrawLGDraw(*lg);
}
void PETSC_STDCALL  petscdrawlgprint_(PetscDrawLG *lg, int *ierr ){
*ierr = PetscDrawLGPrint(*lg);
}
void PETSC_STDCALL  petscdrawlgsetlimits_(PetscDrawLG *lg,PetscReal *x_min,PetscReal *x_max,PetscReal *y_min,PetscReal *y_max, int *ierr ){
*ierr = PetscDrawLGSetLimits(*lg,*x_min,*x_max,*y_min,*y_max);
}
void PETSC_STDCALL  petscdrawlgspdraw_(PetscDrawLG *lg,PetscDrawSP *spin, int *ierr ){
*ierr = PetscDrawLGSPDraw(*lg,*spin);
}
#if defined(__cplusplus)
}
#endif
