/* party.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "petscfix.h"
#include "petscmat.h"
#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matpartitioningpartysetcoarselevel_ PMATPARTITIONINGPARTYSETCOARSELEVEL
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matpartitioningpartysetcoarselevel_ pmatpartitioningpartysetcoarselevel
#else
#define matpartitioningpartysetcoarselevel_ pmatpartitioningpartysetcoarselevel_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matpartitioningpartysetcoarselevel_ MATPARTITIONINGPARTYSETCOARSELEVEL
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matpartitioningpartysetcoarselevel_ matpartitioningpartysetcoarselevel
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matpartitioningpartysetmatchoptimization_ PMATPARTITIONINGPARTYSETMATCHOPTIMIZATION
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matpartitioningpartysetmatchoptimization_ pmatpartitioningpartysetmatchoptimization
#else
#define matpartitioningpartysetmatchoptimization_ pmatpartitioningpartysetmatchoptimization_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matpartitioningpartysetmatchoptimization_ MATPARTITIONINGPARTYSETMATCHOPTIMIZATION
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matpartitioningpartysetmatchoptimization_ matpartitioningpartysetmatchoptimization
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matpartitioningpartysetbipart_ PMATPARTITIONINGPARTYSETBIPART
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matpartitioningpartysetbipart_ pmatpartitioningpartysetbipart
#else
#define matpartitioningpartysetbipart_ pmatpartitioningpartysetbipart_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matpartitioningpartysetbipart_ MATPARTITIONINGPARTYSETBIPART
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matpartitioningpartysetbipart_ matpartitioningpartysetbipart
#endif
#endif



/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL  matpartitioningpartysetcoarselevel_(MatPartitioning *part,PetscReal *level, int *ierr ){
*ierr = MatPartitioningPartySetCoarseLevel(*part,*level);
}
void PETSC_STDCALL  matpartitioningpartysetmatchoptimization_(MatPartitioning *part,
    PetscTruth *opt, int *ierr ){
*ierr = MatPartitioningPartySetMatchOptimization(*part,*opt);
}
void PETSC_STDCALL  matpartitioningpartysetbipart_(MatPartitioning *part,PetscTruth *bp, int *ierr ){
*ierr = MatPartitioningPartySetBipart(*part,*bp);
}
#if defined(__cplusplus)
}
#endif
