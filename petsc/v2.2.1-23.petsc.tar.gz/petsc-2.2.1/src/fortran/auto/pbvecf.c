/* pbvec.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "petscfix.h"
#include "petscvec.h"
#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define vecghostupdatebegin_ PVECGHOSTUPDATEBEGIN
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define vecghostupdatebegin_ pvecghostupdatebegin
#else
#define vecghostupdatebegin_ pvecghostupdatebegin_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define vecghostupdatebegin_ VECGHOSTUPDATEBEGIN
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define vecghostupdatebegin_ vecghostupdatebegin
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define vecghostupdateend_ PVECGHOSTUPDATEEND
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define vecghostupdateend_ pvecghostupdateend
#else
#define vecghostupdateend_ pvecghostupdateend_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define vecghostupdateend_ VECGHOSTUPDATEEND
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define vecghostupdateend_ vecghostupdateend
#endif
#endif



/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL  vecghostupdatebegin_(Vec g,InsertMode *insertmode,ScatterMode *scattermode, int *ierr ){
*ierr = VecGhostUpdateBegin(
	(Vec)PetscToPointer( (g) ),*insertmode,*scattermode);
}
void PETSC_STDCALL  vecghostupdateend_(Vec g,InsertMode *insertmode,ScatterMode *scattermode, int *ierr ){
*ierr = VecGhostUpdateEnd(
	(Vec)PetscToPointer( (g) ),*insertmode,*scattermode);
}
#if defined(__cplusplus)
}
#endif
