/* snesmfj.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "petscfix.h"
#include "petscsnes.h"
#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matsnesmfsetfromoptions_ PMATSNESMFSETFROMOPTIONS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matsnesmfsetfromoptions_ pmatsnesmfsetfromoptions
#else
#define matsnesmfsetfromoptions_ pmatsnesmfsetfromoptions_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matsnesmfsetfromoptions_ MATSNESMFSETFROMOPTIONS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matsnesmfsetfromoptions_ matsnesmfsetfromoptions
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matsnesmfgeth_ PMATSNESMFGETH
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matsnesmfgeth_ pmatsnesmfgeth
#else
#define matsnesmfgeth_ pmatsnesmfgeth_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matsnesmfgeth_ MATSNESMFGETH
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matsnesmfgeth_ matsnesmfgeth
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matsnesmfsetperiod_ PMATSNESMFSETPERIOD
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matsnesmfsetperiod_ pmatsnesmfsetperiod
#else
#define matsnesmfsetperiod_ pmatsnesmfsetperiod_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matsnesmfsetperiod_ MATSNESMFSETPERIOD
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matsnesmfsetperiod_ matsnesmfsetperiod
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matsnesmfsetfunctionerror_ PMATSNESMFSETFUNCTIONERROR
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matsnesmfsetfunctionerror_ pmatsnesmfsetfunctionerror
#else
#define matsnesmfsetfunctionerror_ pmatsnesmfsetfunctionerror_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matsnesmfsetfunctionerror_ MATSNESMFSETFUNCTIONERROR
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matsnesmfsetfunctionerror_ matsnesmfsetfunctionerror
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matsnesmfaddnullspace_ PMATSNESMFADDNULLSPACE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matsnesmfaddnullspace_ pmatsnesmfaddnullspace
#else
#define matsnesmfaddnullspace_ pmatsnesmfaddnullspace_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matsnesmfaddnullspace_ MATSNESMFADDNULLSPACE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matsnesmfaddnullspace_ matsnesmfaddnullspace
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matsnesmfsethhistory_ PMATSNESMFSETHHISTORY
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matsnesmfsethhistory_ pmatsnesmfsethhistory
#else
#define matsnesmfsethhistory_ pmatsnesmfsethhistory_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matsnesmfsethhistory_ MATSNESMFSETHHISTORY
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matsnesmfsethhistory_ matsnesmfsethhistory
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matsnesmfresethhistory_ PMATSNESMFRESETHHISTORY
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matsnesmfresethhistory_ pmatsnesmfresethhistory
#else
#define matsnesmfresethhistory_ pmatsnesmfresethhistory_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matsnesmfresethhistory_ MATSNESMFRESETHHISTORY
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matsnesmfresethhistory_ matsnesmfresethhistory
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matsnesmfsetbase_ PMATSNESMFSETBASE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matsnesmfsetbase_ pmatsnesmfsetbase
#else
#define matsnesmfsetbase_ pmatsnesmfsetbase_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matsnesmfsetbase_ MATSNESMFSETBASE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matsnesmfsetbase_ matsnesmfsetbase
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matsnesmfcheckpositivity_ PMATSNESMFCHECKPOSITIVITY
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matsnesmfcheckpositivity_ pmatsnesmfcheckpositivity
#else
#define matsnesmfcheckpositivity_ pmatsnesmfcheckpositivity_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matsnesmfcheckpositivity_ MATSNESMFCHECKPOSITIVITY
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matsnesmfcheckpositivity_ matsnesmfcheckpositivity
#endif
#endif



/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL  matsnesmfsetfromoptions_(Mat mat, int *ierr ){
*ierr = MatSNESMFSetFromOptions(
	(Mat)PetscToPointer( (mat) ));
}
void PETSC_STDCALL  matsnesmfgeth_(Mat mat,PetscScalar *h, int *ierr ){
*ierr = MatSNESMFGetH(
	(Mat)PetscToPointer( (mat) ),h);
}
void PETSC_STDCALL  matsnesmfsetperiod_(Mat mat,PetscInt *period, int *ierr ){
*ierr = MatSNESMFSetPeriod(
	(Mat)PetscToPointer( (mat) ),*period);
}
void PETSC_STDCALL  matsnesmfsetfunctionerror_(Mat mat,PetscReal *error, int *ierr ){
*ierr = MatSNESMFSetFunctionError(
	(Mat)PetscToPointer( (mat) ),*error);
}
void PETSC_STDCALL  matsnesmfaddnullspace_(Mat J,MatNullSpace *nullsp, int *ierr ){
*ierr = MatSNESMFAddNullSpace(
	(Mat)PetscToPointer( (J) ),*nullsp);
}
void PETSC_STDCALL  matsnesmfsethhistory_(Mat J,PetscScalar history[],PetscInt *nhistory, int *ierr ){
*ierr = MatSNESMFSetHHistory(
	(Mat)PetscToPointer( (J) ),history,*nhistory);
}
void PETSC_STDCALL  matsnesmfresethhistory_(Mat J, int *ierr ){
*ierr = MatSNESMFResetHHistory(
	(Mat)PetscToPointer( (J) ));
}
void PETSC_STDCALL  matsnesmfsetbase_(Mat J,Vec U, int *ierr ){
*ierr = MatSNESMFSetBase(
	(Mat)PetscToPointer( (J) ),
	(Vec)PetscToPointer( (U) ));
}
void PETSC_STDCALL  matsnesmfcheckpositivity_(Vec U,Vec a,PetscScalar *h,void*dummy, int *ierr ){
*ierr = MatSNESMFCheckPositivity(
	(Vec)PetscToPointer( (U) ),
	(Vec)PetscToPointer( (a) ),h,dummy);
}
#if defined(__cplusplus)
}
#endif
