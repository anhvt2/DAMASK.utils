#include "petsc.h"
#include "petscfix.h"
/* axis.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "petsc.h"
#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawaxissetcolors_ PPETSCDRAWAXISSETCOLORS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawaxissetcolors_ ppetscdrawaxissetcolors
#else
#define petscdrawaxissetcolors_ ppetscdrawaxissetcolors_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawaxissetcolors_ PETSCDRAWAXISSETCOLORS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawaxissetcolors_ petscdrawaxissetcolors
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawaxissetholdlimits_ PPETSCDRAWAXISSETHOLDLIMITS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawaxissetholdlimits_ ppetscdrawaxissetholdlimits
#else
#define petscdrawaxissetholdlimits_ ppetscdrawaxissetholdlimits_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawaxissetholdlimits_ PETSCDRAWAXISSETHOLDLIMITS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawaxissetholdlimits_ petscdrawaxissetholdlimits
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawaxissetlimits_ PPETSCDRAWAXISSETLIMITS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawaxissetlimits_ ppetscdrawaxissetlimits
#else
#define petscdrawaxissetlimits_ ppetscdrawaxissetlimits_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawaxissetlimits_ PETSCDRAWAXISSETLIMITS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawaxissetlimits_ petscdrawaxissetlimits
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawaxisdraw_ PPETSCDRAWAXISDRAW
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawaxisdraw_ ppetscdrawaxisdraw
#else
#define petscdrawaxisdraw_ ppetscdrawaxisdraw_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawaxisdraw_ PETSCDRAWAXISDRAW
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawaxisdraw_ petscdrawaxisdraw
#endif
#endif



/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL   petscdrawaxissetcolors_(PetscDrawAxis axis,int *ac,int *tc,int *cc, int *__ierr ){
*__ierr = PetscDrawAxisSetColors(
	(PetscDrawAxis)PetscToPointer((axis) ),*ac,*tc,*cc);
}
void PETSC_STDCALL   petscdrawaxissetholdlimits_(PetscDrawAxis axis,PetscTruth *hold, int *__ierr ){
*__ierr = PetscDrawAxisSetHoldLimits(
	(PetscDrawAxis)PetscToPointer((axis) ),*hold);
}
void PETSC_STDCALL   petscdrawaxissetlimits_(PetscDrawAxis axis,PetscReal *xmin,PetscReal *xmax,PetscReal *ymin,PetscReal *ymax, int *__ierr ){
*__ierr = PetscDrawAxisSetLimits(
	(PetscDrawAxis)PetscToPointer((axis) ),*xmin,*xmax,*ymin,*ymax);
}
void PETSC_STDCALL   petscdrawaxisdraw_(PetscDrawAxis axis, int *__ierr ){
*__ierr = PetscDrawAxisDraw(
	(PetscDrawAxis)PetscToPointer((axis) ));
}
#if defined(__cplusplus)
}
#endif
