#include "petsc.h"
#include "petscfix.h"
/* binv.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "petsc.h"
#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscviewerbinaryskipinfo_ PPETSCVIEWERBINARYSKIPINFO
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscviewerbinaryskipinfo_ ppetscviewerbinaryskipinfo
#else
#define petscviewerbinaryskipinfo_ ppetscviewerbinaryskipinfo_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscviewerbinaryskipinfo_ PETSCVIEWERBINARYSKIPINFO
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscviewerbinaryskipinfo_ petscviewerbinaryskipinfo
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscviewerbinarysetskipoptions_ PPETSCVIEWERBINARYSETSKIPOPTIONS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscviewerbinarysetskipoptions_ ppetscviewerbinarysetskipoptions
#else
#define petscviewerbinarysetskipoptions_ ppetscviewerbinarysetskipoptions_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscviewerbinarysetskipoptions_ PETSCVIEWERBINARYSETSKIPOPTIONS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscviewerbinarysetskipoptions_ petscviewerbinarysetskipoptions
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscviewerbinarygetskipoptions_ PPETSCVIEWERBINARYGETSKIPOPTIONS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscviewerbinarygetskipoptions_ ppetscviewerbinarygetskipoptions
#else
#define petscviewerbinarygetskipoptions_ ppetscviewerbinarygetskipoptions_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscviewerbinarygetskipoptions_ PETSCVIEWERBINARYGETSKIPOPTIONS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscviewerbinarygetskipoptions_ petscviewerbinarygetskipoptions
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscviewerbinaryloadinfo_ PPETSCVIEWERBINARYLOADINFO
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscviewerbinaryloadinfo_ ppetscviewerbinaryloadinfo
#else
#define petscviewerbinaryloadinfo_ ppetscviewerbinaryloadinfo_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscviewerbinaryloadinfo_ PETSCVIEWERBINARYLOADINFO
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscviewerbinaryloadinfo_ petscviewerbinaryloadinfo
#endif
#endif



/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL   petscviewerbinaryskipinfo_(PetscViewer viewer, int *__ierr ){
*__ierr = PetscViewerBinarySkipInfo(
	(PetscViewer)PetscToPointer((viewer) ));
}
void PETSC_STDCALL   petscviewerbinarysetskipoptions_(PetscViewer viewer,PetscTruth *skip, int *__ierr ){
*__ierr = PetscViewerBinarySetSkipOptions(
	(PetscViewer)PetscToPointer((viewer) ),*skip);
}
void PETSC_STDCALL   petscviewerbinarygetskipoptions_(PetscViewer viewer,PetscTruth *skip, int *__ierr ){
*__ierr = PetscViewerBinaryGetSkipOptions(
	(PetscViewer)PetscToPointer((viewer) ),skip);
}
void PETSC_STDCALL   petscviewerbinaryloadinfo_(PetscViewer viewer, int *__ierr ){
*__ierr = PetscViewerBinaryLoadInfo(
	(PetscViewer)PetscToPointer((viewer) ));
}
#if defined(__cplusplus)
}
#endif
