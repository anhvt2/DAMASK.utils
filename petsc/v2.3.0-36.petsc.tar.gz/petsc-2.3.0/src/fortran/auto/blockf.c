#include "petsc.h"
#include "petscfix.h"
/* block.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "petscis.h"
#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define isblockgetblocksize_ PISBLOCKGETBLOCKSIZE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define isblockgetblocksize_ pisblockgetblocksize
#else
#define isblockgetblocksize_ pisblockgetblocksize_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define isblockgetblocksize_ ISBLOCKGETBLOCKSIZE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define isblockgetblocksize_ isblockgetblocksize
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define isblockgetsize_ PISBLOCKGETSIZE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define isblockgetsize_ pisblockgetsize
#else
#define isblockgetsize_ pisblockgetsize_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define isblockgetsize_ ISBLOCKGETSIZE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define isblockgetsize_ isblockgetsize
#endif
#endif



/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL   isblockgetblocksize_(IS is,PetscInt *size, int *__ierr ){
*__ierr = ISBlockGetBlockSize(
	(IS)PetscToPointer((is) ),size);
}
void PETSC_STDCALL   isblockgetsize_(IS is,PetscInt *size, int *__ierr ){
*__ierr = ISBlockGetSize(
	(IS)PetscToPointer((is) ),size);
}
#if defined(__cplusplus)
}
#endif
