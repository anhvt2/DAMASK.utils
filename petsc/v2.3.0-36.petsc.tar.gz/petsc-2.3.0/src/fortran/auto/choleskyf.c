#include "petsc.h"
#include "petscfix.h"
/* cholesky.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "petscpc.h"
#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pccholeskysetreuseordering_ PPCCHOLESKYSETREUSEORDERING
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pccholeskysetreuseordering_ ppccholeskysetreuseordering
#else
#define pccholeskysetreuseordering_ ppccholeskysetreuseordering_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pccholeskysetreuseordering_ PCCHOLESKYSETREUSEORDERING
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pccholeskysetreuseordering_ pccholeskysetreuseordering
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pccholeskysetreusefill_ PPCCHOLESKYSETREUSEFILL
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pccholeskysetreusefill_ ppccholeskysetreusefill
#else
#define pccholeskysetreusefill_ ppccholeskysetreusefill_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pccholeskysetreusefill_ PCCHOLESKYSETREUSEFILL
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pccholeskysetreusefill_ pccholeskysetreusefill
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pccholeskysetfill_ PPCCHOLESKYSETFILL
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pccholeskysetfill_ ppccholeskysetfill
#else
#define pccholeskysetfill_ ppccholeskysetfill_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pccholeskysetfill_ PCCHOLESKYSETFILL
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pccholeskysetfill_ pccholeskysetfill
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pccholeskysetuseinplace_ PPCCHOLESKYSETUSEINPLACE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pccholeskysetuseinplace_ ppccholeskysetuseinplace
#else
#define pccholeskysetuseinplace_ ppccholeskysetuseinplace_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pccholeskysetuseinplace_ PCCHOLESKYSETUSEINPLACE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pccholeskysetuseinplace_ pccholeskysetuseinplace
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pccholeskysetmatordering_ PPCCHOLESKYSETMATORDERING
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pccholeskysetmatordering_ ppccholeskysetmatordering
#else
#define pccholeskysetmatordering_ ppccholeskysetmatordering_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pccholeskysetmatordering_ PCCHOLESKYSETMATORDERING
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pccholeskysetmatordering_ pccholeskysetmatordering
#endif
#endif



/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL   pccholeskysetreuseordering_(PC pc,PetscTruth *flag, int *__ierr ){
*__ierr = PCCholeskySetReuseOrdering(
	(PC)PetscToPointer((pc) ),*flag);
}
void PETSC_STDCALL   pccholeskysetreusefill_(PC pc,PetscTruth *flag, int *__ierr ){
*__ierr = PCCholeskySetReuseFill(
	(PC)PetscToPointer((pc) ),*flag);
}
void PETSC_STDCALL   pccholeskysetfill_(PC pc,PetscReal *fill, int *__ierr ){
*__ierr = PCCholeskySetFill(
	(PC)PetscToPointer((pc) ),*fill);
}
void PETSC_STDCALL   pccholeskysetuseinplace_(PC pc, int *__ierr ){
*__ierr = PCCholeskySetUseInPlace(
	(PC)PetscToPointer((pc) ));
}
void PETSC_STDCALL   pccholeskysetmatordering_(PC pc,MatOrderingType *ordering, int *__ierr ){
*__ierr = PCCholeskySetMatOrdering(
	(PC)PetscToPointer((pc) ),*ordering);
}
#if defined(__cplusplus)
}
#endif
