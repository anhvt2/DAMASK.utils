#include "petsc.h"
#include "petscfix.h"
/* comb.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "petscvec.h"
#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define vecdotbegin_ PVECDOTBEGIN
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define vecdotbegin_ pvecdotbegin
#else
#define vecdotbegin_ pvecdotbegin_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define vecdotbegin_ VECDOTBEGIN
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define vecdotbegin_ vecdotbegin
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define vecdotend_ PVECDOTEND
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define vecdotend_ pvecdotend
#else
#define vecdotend_ pvecdotend_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define vecdotend_ VECDOTEND
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define vecdotend_ vecdotend
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define vectdotbegin_ PVECTDOTBEGIN
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define vectdotbegin_ pvectdotbegin
#else
#define vectdotbegin_ pvectdotbegin_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define vectdotbegin_ VECTDOTBEGIN
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define vectdotbegin_ vectdotbegin
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define vectdotend_ PVECTDOTEND
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define vectdotend_ pvectdotend
#else
#define vectdotend_ pvectdotend_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define vectdotend_ VECTDOTEND
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define vectdotend_ vectdotend
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define vecnormbegin_ PVECNORMBEGIN
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define vecnormbegin_ pvecnormbegin
#else
#define vecnormbegin_ pvecnormbegin_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define vecnormbegin_ VECNORMBEGIN
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define vecnormbegin_ vecnormbegin
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define vecnormend_ PVECNORMEND
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define vecnormend_ pvecnormend
#else
#define vecnormend_ pvecnormend_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define vecnormend_ VECNORMEND
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define vecnormend_ vecnormend
#endif
#endif



/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL   vecdotbegin_(Vec x,Vec y,PetscScalar *result, int *__ierr ){
*__ierr = VecDotBegin(
	(Vec)PetscToPointer((x) ),
	(Vec)PetscToPointer((y) ),result);
}
void PETSC_STDCALL   vecdotend_(Vec x,Vec y,PetscScalar *result, int *__ierr ){
*__ierr = VecDotEnd(
	(Vec)PetscToPointer((x) ),
	(Vec)PetscToPointer((y) ),result);
}
void PETSC_STDCALL   vectdotbegin_(Vec x,Vec y,PetscScalar *result, int *__ierr ){
*__ierr = VecTDotBegin(
	(Vec)PetscToPointer((x) ),
	(Vec)PetscToPointer((y) ),result);
}
void PETSC_STDCALL   vectdotend_(Vec x,Vec y,PetscScalar *result, int *__ierr ){
*__ierr = VecTDotEnd(
	(Vec)PetscToPointer((x) ),
	(Vec)PetscToPointer((y) ),result);
}
void PETSC_STDCALL   vecnormbegin_(Vec x,NormType *ntype,PetscReal *result, int *__ierr ){
*__ierr = VecNormBegin(
	(Vec)PetscToPointer((x) ),*ntype,result);
}
void PETSC_STDCALL   vecnormend_(Vec x,NormType *ntype,PetscReal *result, int *__ierr ){
*__ierr = VecNormEnd(
	(Vec)PetscToPointer((x) ),*ntype,result);
}
#if defined(__cplusplus)
}
#endif
