#include "petsc.h"
#include "petscfix.h"
/* da2.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "petscda.h"
#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define daprinthelp_ PDAPRINTHELP
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define daprinthelp_ pdaprinthelp
#else
#define daprinthelp_ pdaprinthelp_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define daprinthelp_ DAPRINTHELP
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define daprinthelp_ daprinthelp
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define daformfunction1_ PDAFORMFUNCTION1
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define daformfunction1_ pdaformfunction1
#else
#define daformfunction1_ pdaformfunction1_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define daformfunction1_ DAFORMFUNCTION1
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define daformfunction1_ daformfunction1
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define daformfunctioni1_ PDAFORMFUNCTIONI1
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define daformfunctioni1_ pdaformfunctioni1
#else
#define daformfunctioni1_ pdaformfunctioni1_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define daformfunctioni1_ DAFORMFUNCTIONI1
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define daformfunctioni1_ daformfunctioni1
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define dacomputejacobian1_ PDACOMPUTEJACOBIAN1
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define dacomputejacobian1_ pdacomputejacobian1
#else
#define dacomputejacobian1_ pdacomputejacobian1_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define dacomputejacobian1_ DACOMPUTEJACOBIAN1
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define dacomputejacobian1_ dacomputejacobian1
#endif
#endif



/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL   daprinthelp_(DA da, int *__ierr ){
*__ierr = DAPrintHelp(
	(DA)PetscToPointer((da) ));
}
void PETSC_STDCALL   daformfunction1_(DA da,Vec vu,Vec vfu,void*w, int *__ierr ){
*__ierr = DAFormFunction1(
	(DA)PetscToPointer((da) ),
	(Vec)PetscToPointer((vu) ),
	(Vec)PetscToPointer((vfu) ),w);
}
void PETSC_STDCALL   daformfunctioni1_(DA da,PetscInt *i,Vec vu,PetscScalar *vfu,void*w, int *__ierr ){
*__ierr = DAFormFunctioni1(
	(DA)PetscToPointer((da) ),*i,
	(Vec)PetscToPointer((vu) ),vfu,w);
}
void PETSC_STDCALL   dacomputejacobian1_(DA da,Vec vu,Mat J,void*w, int *__ierr ){
*__ierr = DAComputeJacobian1(
	(DA)PetscToPointer((da) ),
	(Vec)PetscToPointer((vu) ),
	(Mat)PetscToPointer((J) ),w);
}
#if defined(__cplusplus)
}
#endif
