#include "petsc.h"
#include "petscfix.h"
/* dagtol.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "petscda.h"
#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define daglobaltolocalbegin_ PDAGLOBALTOLOCALBEGIN
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define daglobaltolocalbegin_ pdaglobaltolocalbegin
#else
#define daglobaltolocalbegin_ pdaglobaltolocalbegin_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define daglobaltolocalbegin_ DAGLOBALTOLOCALBEGIN
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define daglobaltolocalbegin_ daglobaltolocalbegin
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define dalocaltoglobalbegin_ PDALOCALTOGLOBALBEGIN
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define dalocaltoglobalbegin_ pdalocaltoglobalbegin
#else
#define dalocaltoglobalbegin_ pdalocaltoglobalbegin_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define dalocaltoglobalbegin_ DALOCALTOGLOBALBEGIN
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define dalocaltoglobalbegin_ dalocaltoglobalbegin
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define dalocaltoglobalend_ PDALOCALTOGLOBALEND
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define dalocaltoglobalend_ pdalocaltoglobalend
#else
#define dalocaltoglobalend_ pdalocaltoglobalend_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define dalocaltoglobalend_ DALOCALTOGLOBALEND
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define dalocaltoglobalend_ dalocaltoglobalend
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define daglobaltolocalend_ PDAGLOBALTOLOCALEND
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define daglobaltolocalend_ pdaglobaltolocalend
#else
#define daglobaltolocalend_ pdaglobaltolocalend_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define daglobaltolocalend_ DAGLOBALTOLOCALEND
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define daglobaltolocalend_ daglobaltolocalend
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define daglobaltonaturalbegin_ PDAGLOBALTONATURALBEGIN
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define daglobaltonaturalbegin_ pdaglobaltonaturalbegin
#else
#define daglobaltonaturalbegin_ pdaglobaltonaturalbegin_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define daglobaltonaturalbegin_ DAGLOBALTONATURALBEGIN
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define daglobaltonaturalbegin_ daglobaltonaturalbegin
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define daglobaltonaturalend_ PDAGLOBALTONATURALEND
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define daglobaltonaturalend_ pdaglobaltonaturalend
#else
#define daglobaltonaturalend_ pdaglobaltonaturalend_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define daglobaltonaturalend_ DAGLOBALTONATURALEND
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define daglobaltonaturalend_ daglobaltonaturalend
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define danaturaltoglobalbegin_ PDANATURALTOGLOBALBEGIN
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define danaturaltoglobalbegin_ pdanaturaltoglobalbegin
#else
#define danaturaltoglobalbegin_ pdanaturaltoglobalbegin_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define danaturaltoglobalbegin_ DANATURALTOGLOBALBEGIN
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define danaturaltoglobalbegin_ danaturaltoglobalbegin
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define danaturaltoglobalend_ PDANATURALTOGLOBALEND
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define danaturaltoglobalend_ pdanaturaltoglobalend
#else
#define danaturaltoglobalend_ pdanaturaltoglobalend_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define danaturaltoglobalend_ DANATURALTOGLOBALEND
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define danaturaltoglobalend_ danaturaltoglobalend
#endif
#endif



/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL   daglobaltolocalbegin_(DA da,Vec g,InsertMode *mode,Vec l, int *__ierr ){
*__ierr = DAGlobalToLocalBegin(
	(DA)PetscToPointer((da) ),
	(Vec)PetscToPointer((g) ),*mode,
	(Vec)PetscToPointer((l) ));
}
void PETSC_STDCALL   dalocaltoglobalbegin_(DA da,Vec l,Vec g, int *__ierr ){
*__ierr = DALocalToGlobalBegin(
	(DA)PetscToPointer((da) ),
	(Vec)PetscToPointer((l) ),
	(Vec)PetscToPointer((g) ));
}
void PETSC_STDCALL   dalocaltoglobalend_(DA da,Vec l,Vec g, int *__ierr ){
*__ierr = DALocalToGlobalEnd(
	(DA)PetscToPointer((da) ),
	(Vec)PetscToPointer((l) ),
	(Vec)PetscToPointer((g) ));
}
void PETSC_STDCALL   daglobaltolocalend_(DA da,Vec g,InsertMode *mode,Vec l, int *__ierr ){
*__ierr = DAGlobalToLocalEnd(
	(DA)PetscToPointer((da) ),
	(Vec)PetscToPointer((g) ),*mode,
	(Vec)PetscToPointer((l) ));
}
void PETSC_STDCALL   daglobaltonaturalbegin_(DA da,Vec g,InsertMode *mode,Vec l, int *__ierr ){
*__ierr = DAGlobalToNaturalBegin(
	(DA)PetscToPointer((da) ),
	(Vec)PetscToPointer((g) ),*mode,
	(Vec)PetscToPointer((l) ));
}
void PETSC_STDCALL   daglobaltonaturalend_(DA da,Vec g,InsertMode *mode,Vec l, int *__ierr ){
*__ierr = DAGlobalToNaturalEnd(
	(DA)PetscToPointer((da) ),
	(Vec)PetscToPointer((g) ),*mode,
	(Vec)PetscToPointer((l) ));
}
void PETSC_STDCALL   danaturaltoglobalbegin_(DA da,Vec g,InsertMode *mode,Vec l, int *__ierr ){
*__ierr = DANaturalToGlobalBegin(
	(DA)PetscToPointer((da) ),
	(Vec)PetscToPointer((g) ),*mode,
	(Vec)PetscToPointer((l) ));
}
void PETSC_STDCALL   danaturaltoglobalend_(DA da,Vec g,InsertMode *mode,Vec l, int *__ierr ){
*__ierr = DANaturalToGlobalEnd(
	(DA)PetscToPointer((da) ),
	(Vec)PetscToPointer((g) ),*mode,
	(Vec)PetscToPointer((l) ));
}
#if defined(__cplusplus)
}
#endif
