#include "petsc.h"
#include "petscfix.h"
/* draw.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "petscdraw.h"
#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawresizewindow_ PPETSCDRAWRESIZEWINDOW
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawresizewindow_ ppetscdrawresizewindow
#else
#define petscdrawresizewindow_ ppetscdrawresizewindow_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawresizewindow_ PETSCDRAWRESIZEWINDOW
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawresizewindow_ petscdrawresizewindow
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawcheckresizedwindow_ PPETSCDRAWCHECKRESIZEDWINDOW
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawcheckresizedwindow_ ppetscdrawcheckresizedwindow
#else
#define petscdrawcheckresizedwindow_ ppetscdrawcheckresizedwindow_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawcheckresizedwindow_ PETSCDRAWCHECKRESIZEDWINDOW
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawcheckresizedwindow_ petscdrawcheckresizedwindow
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawsetdisplay_ PPETSCDRAWSETDISPLAY
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawsetdisplay_ ppetscdrawsetdisplay
#else
#define petscdrawsetdisplay_ ppetscdrawsetdisplay_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawsetdisplay_ PETSCDRAWSETDISPLAY
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawsetdisplay_ petscdrawsetdisplay
#endif
#endif



/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL   petscdrawresizewindow_(PetscDraw draw,int *w,int *h, int *__ierr ){
*__ierr = PetscDrawResizeWindow(
	(PetscDraw)PetscToPointer((draw) ),*w,*h);
}
void PETSC_STDCALL   petscdrawcheckresizedwindow_(PetscDraw draw, int *__ierr ){
*__ierr = PetscDrawCheckResizedWindow(
	(PetscDraw)PetscToPointer((draw) ));
}
void PETSC_STDCALL   petscdrawsetdisplay_(PetscDraw draw,char *display, int *__ierr ){
*__ierr = PetscDrawSetDisplay(
	(PetscDraw)PetscToPointer((draw) ),display);
}
#if defined(__cplusplus)
}
#endif
