#include "petsc.h"
#include "petscfix.h"
/* isltog.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "petscsys.h"
#include "petscis.h"
#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define islocaltoglobalmappingdestroy_ PISLOCALTOGLOBALMAPPINGDESTROY
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define islocaltoglobalmappingdestroy_ pislocaltoglobalmappingdestroy
#else
#define islocaltoglobalmappingdestroy_ pislocaltoglobalmappingdestroy_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define islocaltoglobalmappingdestroy_ ISLOCALTOGLOBALMAPPINGDESTROY
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define islocaltoglobalmappingdestroy_ islocaltoglobalmappingdestroy
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define islocaltoglobalmappingapplyis_ PISLOCALTOGLOBALMAPPINGAPPLYIS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define islocaltoglobalmappingapplyis_ pislocaltoglobalmappingapplyis
#else
#define islocaltoglobalmappingapplyis_ pislocaltoglobalmappingapplyis_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define islocaltoglobalmappingapplyis_ ISLOCALTOGLOBALMAPPINGAPPLYIS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define islocaltoglobalmappingapplyis_ islocaltoglobalmappingapplyis
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define isglobaltolocalmappingapply_ PISGLOBALTOLOCALMAPPINGAPPLY
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define isglobaltolocalmappingapply_ pisglobaltolocalmappingapply
#else
#define isglobaltolocalmappingapply_ pisglobaltolocalmappingapply_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define isglobaltolocalmappingapply_ ISGLOBALTOLOCALMAPPINGAPPLY
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define isglobaltolocalmappingapply_ isglobaltolocalmappingapply
#endif
#endif



/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL   islocaltoglobalmappingdestroy_(ISLocalToGlobalMapping mapping, int *__ierr ){
*__ierr = ISLocalToGlobalMappingDestroy(
	(ISLocalToGlobalMapping)PetscToPointer((mapping) ));
}
void PETSC_STDCALL   islocaltoglobalmappingapplyis_(ISLocalToGlobalMapping mapping,IS is,IS *newis, int *__ierr ){
*__ierr = ISLocalToGlobalMappingApplyIS(
	(ISLocalToGlobalMapping)PetscToPointer((mapping) ),
	(IS)PetscToPointer((is) ),newis);
}
void PETSC_STDCALL   isglobaltolocalmappingapply_(ISLocalToGlobalMapping mapping,ISGlobalToLocalMappingType *type,
                                  PetscInt *n, PetscInt idx[],PetscInt *nout,PetscInt idxout[], int *__ierr ){
*__ierr = ISGlobalToLocalMappingApply(
	(ISLocalToGlobalMapping)PetscToPointer((mapping) ),*type,*n,idx,nout,idxout);
}
#if defined(__cplusplus)
}
#endif
