#include "petsc.h"
#include "petscfix.h"
/* lu.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "petscpc.h"
#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pclureorderfornonzerodiagonal_ PPCLUREORDERFORNONZERODIAGONAL
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pclureorderfornonzerodiagonal_ ppclureorderfornonzerodiagonal
#else
#define pclureorderfornonzerodiagonal_ ppclureorderfornonzerodiagonal_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pclureorderfornonzerodiagonal_ PCLUREORDERFORNONZERODIAGONAL
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pclureorderfornonzerodiagonal_ pclureorderfornonzerodiagonal
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pclusetreuseordering_ PPCLUSETREUSEORDERING
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pclusetreuseordering_ ppclusetreuseordering
#else
#define pclusetreuseordering_ ppclusetreuseordering_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pclusetreuseordering_ PCLUSETREUSEORDERING
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pclusetreuseordering_ pclusetreuseordering
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pclusetreusefill_ PPCLUSETREUSEFILL
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pclusetreusefill_ ppclusetreusefill
#else
#define pclusetreusefill_ ppclusetreusefill_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pclusetreusefill_ PCLUSETREUSEFILL
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pclusetreusefill_ pclusetreusefill
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pclusetfill_ PPCLUSETFILL
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pclusetfill_ ppclusetfill
#else
#define pclusetfill_ ppclusetfill_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pclusetfill_ PCLUSETFILL
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pclusetfill_ pclusetfill
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pclusetuseinplace_ PPCLUSETUSEINPLACE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pclusetuseinplace_ ppclusetuseinplace
#else
#define pclusetuseinplace_ ppclusetuseinplace_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pclusetuseinplace_ PCLUSETUSEINPLACE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pclusetuseinplace_ pclusetuseinplace
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pclusetpivoting_ PPCLUSETPIVOTING
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pclusetpivoting_ ppclusetpivoting
#else
#define pclusetpivoting_ ppclusetpivoting_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pclusetpivoting_ PCLUSETPIVOTING
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pclusetpivoting_ pclusetpivoting
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pclusetpivotinblocks_ PPCLUSETPIVOTINBLOCKS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pclusetpivotinblocks_ ppclusetpivotinblocks
#else
#define pclusetpivotinblocks_ ppclusetpivotinblocks_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pclusetpivotinblocks_ PCLUSETPIVOTINBLOCKS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pclusetpivotinblocks_ pclusetpivotinblocks
#endif
#endif



/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL   pclureorderfornonzerodiagonal_(PC pc,PetscReal *rtol, int *__ierr ){
*__ierr = PCLUReorderForNonzeroDiagonal(
	(PC)PetscToPointer((pc) ),*rtol);
}
void PETSC_STDCALL   pclusetreuseordering_(PC pc,PetscTruth *flag, int *__ierr ){
*__ierr = PCLUSetReuseOrdering(
	(PC)PetscToPointer((pc) ),*flag);
}
void PETSC_STDCALL   pclusetreusefill_(PC pc,PetscTruth *flag, int *__ierr ){
*__ierr = PCLUSetReuseFill(
	(PC)PetscToPointer((pc) ),*flag);
}
void PETSC_STDCALL   pclusetfill_(PC pc,PetscReal *fill, int *__ierr ){
*__ierr = PCLUSetFill(
	(PC)PetscToPointer((pc) ),*fill);
}
void PETSC_STDCALL   pclusetuseinplace_(PC pc, int *__ierr ){
*__ierr = PCLUSetUseInPlace(
	(PC)PetscToPointer((pc) ));
}
void PETSC_STDCALL   pclusetpivoting_(PC pc,PetscReal *dtcol, int *__ierr ){
*__ierr = PCLUSetPivoting(
	(PC)PetscToPointer((pc) ),*dtcol);
}
void PETSC_STDCALL   pclusetpivotinblocks_(PC pc,PetscTruth *pivot, int *__ierr ){
*__ierr = PCLUSetPivotInBlocks(
	(PC)PetscToPointer((pc) ),*pivot);
}
#if defined(__cplusplus)
}
#endif
