#include "petsc.h"
#include "petscfix.h"
/* map.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "petscvec.h"
#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscmapprinthelp_ PPETSCMAPPRINTHELP
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscmapprinthelp_ ppetscmapprinthelp
#else
#define petscmapprinthelp_ ppetscmapprinthelp_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscmapprinthelp_ PETSCMAPPRINTHELP
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscmapprinthelp_ petscmapprinthelp
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscmapsetup_ PPETSCMAPSETUP
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscmapsetup_ ppetscmapsetup
#else
#define petscmapsetup_ ppetscmapsetup_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscmapsetup_ PETSCMAPSETUP
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscmapsetup_ petscmapsetup
#endif
#endif



/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL   petscmapprinthelp_(PetscMap map, int *__ierr ){
*__ierr = PetscMapPrintHelp(
	(PetscMap)PetscToPointer((map) ));
}
void PETSC_STDCALL   petscmapsetup_(PetscMap map, int *__ierr ){
*__ierr = PetscMapSetUp(
	(PetscMap)PetscToPointer((map) ));
}
#if defined(__cplusplus)
}
#endif
