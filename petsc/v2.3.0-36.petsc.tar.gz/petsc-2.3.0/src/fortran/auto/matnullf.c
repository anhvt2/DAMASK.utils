#include "petsc.h"
#include "petscfix.h"
/* matnull.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "petscmat.h"
#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matnullspacedestroy_ PMATNULLSPACEDESTROY
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matnullspacedestroy_ pmatnullspacedestroy
#else
#define matnullspacedestroy_ pmatnullspacedestroy_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matnullspacedestroy_ MATNULLSPACEDESTROY
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matnullspacedestroy_ matnullspacedestroy
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matnullspaceremove_ PMATNULLSPACEREMOVE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matnullspaceremove_ pmatnullspaceremove
#else
#define matnullspaceremove_ pmatnullspaceremove_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matnullspaceremove_ MATNULLSPACEREMOVE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matnullspaceremove_ matnullspaceremove
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matnullspacetest_ PMATNULLSPACETEST
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matnullspacetest_ pmatnullspacetest
#else
#define matnullspacetest_ pmatnullspacetest_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matnullspacetest_ MATNULLSPACETEST
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matnullspacetest_ matnullspacetest
#endif
#endif



/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL   matnullspacedestroy_(MatNullSpace sp, int *__ierr ){
*__ierr = MatNullSpaceDestroy(
	(MatNullSpace)PetscToPointer((sp) ));
}
void PETSC_STDCALL   matnullspaceremove_(MatNullSpace sp,Vec vec,Vec *out, int *__ierr ){
*__ierr = MatNullSpaceRemove(
	(MatNullSpace)PetscToPointer((sp) ),
	(Vec)PetscToPointer((vec) ),out);
}
void PETSC_STDCALL   matnullspacetest_(MatNullSpace sp,Mat mat, int *__ierr ){
*__ierr = MatNullSpaceTest(
	(MatNullSpace)PetscToPointer((sp) ),
	(Mat)PetscToPointer((mat) ));
}
#if defined(__cplusplus)
}
#endif
