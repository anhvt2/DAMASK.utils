#include "petsc.h"
#include "petscfix.h"
/* mg.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "petscmg.h"
#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pcmggetlevels_ PPCMGGETLEVELS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pcmggetlevels_ ppcmggetlevels
#else
#define pcmggetlevels_ ppcmggetlevels_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pcmggetlevels_ PCMGGETLEVELS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pcmggetlevels_ pcmggetlevels
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pcmgsettype_ PPCMGSETTYPE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pcmgsettype_ ppcmgsettype
#else
#define pcmgsettype_ ppcmgsettype_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pcmgsettype_ PCMGSETTYPE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pcmgsettype_ pcmgsettype
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pcmgsetcycles_ PPCMGSETCYCLES
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pcmgsetcycles_ ppcmgsetcycles
#else
#define pcmgsetcycles_ ppcmgsetcycles_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pcmgsetcycles_ PCMGSETCYCLES
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pcmgsetcycles_ pcmgsetcycles
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pcmgsetgalerkin_ PPCMGSETGALERKIN
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pcmgsetgalerkin_ ppcmgsetgalerkin
#else
#define pcmgsetgalerkin_ ppcmgsetgalerkin_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pcmgsetgalerkin_ PCMGSETGALERKIN
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pcmgsetgalerkin_ pcmgsetgalerkin
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pcmgsetnumbersmoothdown_ PPCMGSETNUMBERSMOOTHDOWN
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pcmgsetnumbersmoothdown_ ppcmgsetnumbersmoothdown
#else
#define pcmgsetnumbersmoothdown_ ppcmgsetnumbersmoothdown_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pcmgsetnumbersmoothdown_ PCMGSETNUMBERSMOOTHDOWN
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pcmgsetnumbersmoothdown_ pcmgsetnumbersmoothdown
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pcmgsetnumbersmoothup_ PPCMGSETNUMBERSMOOTHUP
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pcmgsetnumbersmoothup_ ppcmgsetnumbersmoothup
#else
#define pcmgsetnumbersmoothup_ ppcmgsetnumbersmoothup_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pcmgsetnumbersmoothup_ PCMGSETNUMBERSMOOTHUP
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pcmgsetnumbersmoothup_ pcmgsetnumbersmoothup
#endif
#endif



/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL   pcmggetlevels_(PC pc,PetscInt *levels, int *__ierr ){
*__ierr = PCMGGetLevels(
	(PC)PetscToPointer((pc) ),levels);
}
void PETSC_STDCALL   pcmgsettype_(PC pc,PCMGType *form, int *__ierr ){
*__ierr = PCMGSetType(
	(PC)PetscToPointer((pc) ),*form);
}
void PETSC_STDCALL   pcmgsetcycles_(PC pc,PetscInt *n, int *__ierr ){
*__ierr = PCMGSetCycles(
	(PC)PetscToPointer((pc) ),*n);
}
void PETSC_STDCALL   pcmgsetgalerkin_(PC pc, int *__ierr ){
*__ierr = PCMGSetGalerkin(
	(PC)PetscToPointer((pc) ));
}
void PETSC_STDCALL   pcmgsetnumbersmoothdown_(PC pc,PetscInt *n, int *__ierr ){
*__ierr = PCMGSetNumberSmoothDown(
	(PC)PetscToPointer((pc) ),*n);
}
void PETSC_STDCALL   pcmgsetnumbersmoothup_(PC pc,PetscInt *n, int *__ierr ){
*__ierr = PCMGSetNumberSmoothUp(
	(PC)PetscToPointer((pc) ),*n);
}
#if defined(__cplusplus)
}
#endif
