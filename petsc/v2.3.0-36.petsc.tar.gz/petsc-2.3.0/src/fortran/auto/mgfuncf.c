#include "petsc.h"
#include "petscfix.h"
/* mgfunc.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "petscksp.h"
#include "petscmg.h"
#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pcmgsetinterpolate_ PPCMGSETINTERPOLATE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pcmgsetinterpolate_ ppcmgsetinterpolate
#else
#define pcmgsetinterpolate_ ppcmgsetinterpolate_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pcmgsetinterpolate_ PCMGSETINTERPOLATE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pcmgsetinterpolate_ pcmgsetinterpolate
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pcmgsetrestriction_ PPCMGSETRESTRICTION
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pcmgsetrestriction_ ppcmgsetrestriction
#else
#define pcmgsetrestriction_ ppcmgsetrestriction_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pcmgsetrestriction_ PCMGSETRESTRICTION
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pcmgsetrestriction_ pcmgsetrestriction
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pcmgsetcyclesonlevel_ PPCMGSETCYCLESONLEVEL
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pcmgsetcyclesonlevel_ ppcmgsetcyclesonlevel
#else
#define pcmgsetcyclesonlevel_ ppcmgsetcyclesonlevel_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pcmgsetcyclesonlevel_ PCMGSETCYCLESONLEVEL
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pcmgsetcyclesonlevel_ pcmgsetcyclesonlevel
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pcmgsetrhs_ PPCMGSETRHS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pcmgsetrhs_ ppcmgsetrhs
#else
#define pcmgsetrhs_ ppcmgsetrhs_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pcmgsetrhs_ PCMGSETRHS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pcmgsetrhs_ pcmgsetrhs
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pcmgsetx_ PPCMGSETX
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pcmgsetx_ ppcmgsetx
#else
#define pcmgsetx_ ppcmgsetx_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pcmgsetx_ PCMGSETX
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pcmgsetx_ pcmgsetx
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pcmgsetr_ PPCMGSETR
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pcmgsetr_ ppcmgsetr
#else
#define pcmgsetr_ ppcmgsetr_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pcmgsetr_ PCMGSETR
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pcmgsetr_ pcmgsetr
#endif
#endif



/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL   pcmgsetinterpolate_(PC pc,PetscInt *l,Mat mat, int *__ierr ){
*__ierr = PCMGSetInterpolate(
	(PC)PetscToPointer((pc) ),*l,
	(Mat)PetscToPointer((mat) ));
}
void PETSC_STDCALL   pcmgsetrestriction_(PC pc,PetscInt *l,Mat mat, int *__ierr ){
*__ierr = PCMGSetRestriction(
	(PC)PetscToPointer((pc) ),*l,
	(Mat)PetscToPointer((mat) ));
}
void PETSC_STDCALL   pcmgsetcyclesonlevel_(PC pc,PetscInt *l,PetscInt *c, int *__ierr ){
*__ierr = PCMGSetCyclesOnLevel(
	(PC)PetscToPointer((pc) ),*l,*c);
}
void PETSC_STDCALL   pcmgsetrhs_(PC pc,PetscInt *l,Vec c, int *__ierr ){
*__ierr = PCMGSetRhs(
	(PC)PetscToPointer((pc) ),*l,
	(Vec)PetscToPointer((c) ));
}
void PETSC_STDCALL   pcmgsetx_(PC pc,PetscInt *l,Vec c, int *__ierr ){
*__ierr = PCMGSetX(
	(PC)PetscToPointer((pc) ),*l,
	(Vec)PetscToPointer((c) ));
}
void PETSC_STDCALL   pcmgsetr_(PC pc,PetscInt *l,Vec c, int *__ierr ){
*__ierr = PCMGSetR(
	(PC)PetscToPointer((pc) ),*l,
	(Vec)PetscToPointer((c) ));
}
#if defined(__cplusplus)
}
#endif
