#include "petsc.h"
#include "petscfix.h"
/* petscda.h */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define da_stencil_star_ PDA_STENCIL_STAR
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define da_stencil_star_ pda_stencil_star__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define da_stencil_star_ pda_stencil_star
#else
#define da_stencil_star_ pda_stencil_star_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define da_stencil_star_ DA_STENCIL_STAR
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define da_stencil_star_ da_stencil_star__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define da_stencil_star_ da_stencil_star
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define da_stencil_box_ PDA_STENCIL_BOX
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define da_stencil_box_ pda_stencil_box__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define da_stencil_box_ pda_stencil_box
#else
#define da_stencil_box_ pda_stencil_box_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define da_stencil_box_ DA_STENCIL_BOX
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define da_stencil_box_ da_stencil_box__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define da_stencil_box_ da_stencil_box
#endif
#endif



/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
#if defined(__cplusplus)
}
#endif
