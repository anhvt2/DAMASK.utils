#include "petsc.h"
#include "petscfix.h"
/* petsc.h */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsc_false_ PPETSC_FALSE
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define petsc_false_ ppetsc_false__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define petsc_false_ ppetsc_false
#else
#define petsc_false_ ppetsc_false_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsc_false_ PETSC_FALSE
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define petsc_false_ petsc_false__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define petsc_false_ petsc_false
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsc_true_ PPETSC_TRUE
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define petsc_true_ ppetsc_true__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define petsc_true_ ppetsc_true
#else
#define petsc_true_ ppetsc_true_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsc_true_ PETSC_TRUE
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define petsc_true_ petsc_true__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define petsc_true_ petsc_true
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsc_yes_ PPETSC_YES
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define petsc_yes_ ppetsc_yes__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define petsc_yes_ ppetsc_yes
#else
#define petsc_yes_ ppetsc_yes_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsc_yes_ PETSC_YES
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define petsc_yes_ petsc_yes__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define petsc_yes_ petsc_yes
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsc_no_ PPETSC_NO
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define petsc_no_ ppetsc_no__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define petsc_no_ ppetsc_no
#else
#define petsc_no_ ppetsc_no_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsc_no_ PETSC_NO
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define petsc_no_ petsc_no__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define petsc_no_ petsc_no
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsc_null_ PPETSC_NULL
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define petsc_null_ ppetsc_null__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define petsc_null_ ppetsc_null
#else
#define petsc_null_ ppetsc_null_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsc_null_ PETSC_NULL
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define petsc_null_ petsc_null__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define petsc_null_ petsc_null
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsc_decide_ PPETSC_DECIDE
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define petsc_decide_ ppetsc_decide__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define petsc_decide_ ppetsc_decide
#else
#define petsc_decide_ ppetsc_decide_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsc_decide_ PETSC_DECIDE
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define petsc_decide_ petsc_decide__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define petsc_decide_ petsc_decide
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsc_default_ PPETSC_DEFAULT
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define petsc_default_ ppetsc_default__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define petsc_default_ ppetsc_default
#else
#define petsc_default_ ppetsc_default_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsc_default_ PETSC_DEFAULT
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define petsc_default_ petsc_default__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define petsc_default_ petsc_default
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsc_ignore_ PPETSC_IGNORE
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define petsc_ignore_ ppetsc_ignore__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define petsc_ignore_ ppetsc_ignore
#else
#define petsc_ignore_ ppetsc_ignore_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsc_ignore_ PETSC_IGNORE
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define petsc_ignore_ petsc_ignore__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define petsc_ignore_ petsc_ignore
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsc_determine_ PPETSC_DETERMINE
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define petsc_determine_ ppetsc_determine__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define petsc_determine_ ppetsc_determine
#else
#define petsc_determine_ ppetsc_determine_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsc_determine_ PETSC_DETERMINE
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define petsc_determine_ petsc_determine__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define petsc_determine_ petsc_determine
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsc_comm_world_ PPETSC_COMM_WORLD
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define petsc_comm_world_ ppetsc_comm_world__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define petsc_comm_world_ ppetsc_comm_world
#else
#define petsc_comm_world_ ppetsc_comm_world_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsc_comm_world_ PETSC_COMM_WORLD
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define petsc_comm_world_ petsc_comm_world__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define petsc_comm_world_ petsc_comm_world
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsc_comm_self_ PPETSC_COMM_SELF
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define petsc_comm_self_ ppetsc_comm_self__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define petsc_comm_self_ ppetsc_comm_self
#else
#define petsc_comm_self_ ppetsc_comm_self_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsc_comm_self_ PETSC_COMM_SELF
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define petsc_comm_self_ petsc_comm_self__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define petsc_comm_self_ petsc_comm_self
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define size_ PSIZE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define size_ psize
#else
#define size_ psize_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define size_ SIZE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define size_ size
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define rank_ PRANK
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define rank_ prank
#else
#define rank_ prank_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define rank_ RANK
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define rank_ rank
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define comm_ PCOMM
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define comm_ pcomm
#else
#define comm_ pcomm_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define comm_ COMM
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define comm_ comm
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define mpi_comm_ PMPI_COMM
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define mpi_comm_ pmpi_comm__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define mpi_comm_ pmpi_comm
#else
#define mpi_comm_ pmpi_comm_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define mpi_comm_ MPI_COMM
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define mpi_comm_ mpi_comm__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define mpi_comm_ mpi_comm
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscscalar_ PPETSCSCALAR
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscscalar_ ppetscscalar
#else
#define petscscalar_ ppetscscalar_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscscalar_ PETSCSCALAR
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscscalar_ petscscalar
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscreal_ PPETSCREAL
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscreal_ ppetscreal
#else
#define petscreal_ ppetscreal_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscreal_ PETSCREAL
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscreal_ petscreal
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define passivescalar_ PPASSIVESCALAR
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define passivescalar_ ppassivescalar
#else
#define passivescalar_ ppassivescalar_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define passivescalar_ PASSIVESCALAR
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define passivescalar_ passivescalar
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define passivereal_ PPASSIVEREAL
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define passivereal_ ppassivereal
#else
#define passivereal_ ppassivereal_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define passivereal_ PASSIVEREAL
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define passivereal_ passivereal
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define mpiu_scalar_ PMPIU_SCALAR
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define mpiu_scalar_ pmpiu_scalar__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define mpiu_scalar_ pmpiu_scalar
#else
#define mpiu_scalar_ pmpiu_scalar_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define mpiu_scalar_ MPIU_SCALAR
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define mpiu_scalar_ mpiu_scalar__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define mpiu_scalar_ mpiu_scalar
#endif
#endif



/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
#if defined(__cplusplus)
}
#endif
