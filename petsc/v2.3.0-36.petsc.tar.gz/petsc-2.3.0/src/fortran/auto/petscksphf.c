#include "petsc.h"
#include "petscfix.h"
/* petscksp.h */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define ksp_gmres_cgs_refine_never_ PKSP_GMRES_CGS_REFINE_NEVER
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define ksp_gmres_cgs_refine_never_ pksp_gmres_cgs_refine_never__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define ksp_gmres_cgs_refine_never_ pksp_gmres_cgs_refine_never
#else
#define ksp_gmres_cgs_refine_never_ pksp_gmres_cgs_refine_never_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define ksp_gmres_cgs_refine_never_ KSP_GMRES_CGS_REFINE_NEVER
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define ksp_gmres_cgs_refine_never_ ksp_gmres_cgs_refine_never__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define ksp_gmres_cgs_refine_never_ ksp_gmres_cgs_refine_never
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define ksp_gmres_cgs_refine_ifneeded_ PKSP_GMRES_CGS_REFINE_IFNEEDED
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define ksp_gmres_cgs_refine_ifneeded_ pksp_gmres_cgs_refine_ifneeded__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define ksp_gmres_cgs_refine_ifneeded_ pksp_gmres_cgs_refine_ifneeded
#else
#define ksp_gmres_cgs_refine_ifneeded_ pksp_gmres_cgs_refine_ifneeded_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define ksp_gmres_cgs_refine_ifneeded_ KSP_GMRES_CGS_REFINE_IFNEEDED
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define ksp_gmres_cgs_refine_ifneeded_ ksp_gmres_cgs_refine_ifneeded__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define ksp_gmres_cgs_refine_ifneeded_ ksp_gmres_cgs_refine_ifneeded
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define ksp_gmres_cgs_refine_never_ PKSP_GMRES_CGS_REFINE_NEVER
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define ksp_gmres_cgs_refine_never_ pksp_gmres_cgs_refine_never__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define ksp_gmres_cgs_refine_never_ pksp_gmres_cgs_refine_never
#else
#define ksp_gmres_cgs_refine_never_ pksp_gmres_cgs_refine_never_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define ksp_gmres_cgs_refine_never_ KSP_GMRES_CGS_REFINE_NEVER
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define ksp_gmres_cgs_refine_never_ ksp_gmres_cgs_refine_never__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define ksp_gmres_cgs_refine_never_ ksp_gmres_cgs_refine_never
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define ksp_no_norm_ PKSP_NO_NORM
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define ksp_no_norm_ pksp_no_norm__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define ksp_no_norm_ pksp_no_norm
#else
#define ksp_no_norm_ pksp_no_norm_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define ksp_no_norm_ KSP_NO_NORM
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define ksp_no_norm_ ksp_no_norm__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define ksp_no_norm_ ksp_no_norm
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define ksp_preconditioned_norm_ PKSP_PRECONDITIONED_NORM
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define ksp_preconditioned_norm_ pksp_preconditioned_norm__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define ksp_preconditioned_norm_ pksp_preconditioned_norm
#else
#define ksp_preconditioned_norm_ pksp_preconditioned_norm_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define ksp_preconditioned_norm_ KSP_PRECONDITIONED_NORM
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define ksp_preconditioned_norm_ ksp_preconditioned_norm__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define ksp_preconditioned_norm_ ksp_preconditioned_norm
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define ksp_unpreconditioned_norm_ PKSP_UNPRECONDITIONED_NORM
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define ksp_unpreconditioned_norm_ pksp_unpreconditioned_norm__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define ksp_unpreconditioned_norm_ pksp_unpreconditioned_norm
#else
#define ksp_unpreconditioned_norm_ pksp_unpreconditioned_norm_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define ksp_unpreconditioned_norm_ KSP_UNPRECONDITIONED_NORM
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define ksp_unpreconditioned_norm_ ksp_unpreconditioned_norm__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define ksp_unpreconditioned_norm_ ksp_unpreconditioned_norm
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define ksp_natural_norm_ PKSP_NATURAL_NORM
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define ksp_natural_norm_ pksp_natural_norm__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define ksp_natural_norm_ pksp_natural_norm
#else
#define ksp_natural_norm_ pksp_natural_norm_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define ksp_natural_norm_ KSP_NATURAL_NORM
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define ksp_natural_norm_ ksp_natural_norm__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define ksp_natural_norm_ ksp_natural_norm
#endif
#endif



/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
#if defined(__cplusplus)
}
#endif
