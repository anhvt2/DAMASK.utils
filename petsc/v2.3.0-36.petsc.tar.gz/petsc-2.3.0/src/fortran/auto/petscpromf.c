#include "petsc.h"
#include "petscfix.h"
/* petscprom.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "petscpc.h"
#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pcprometheussetcoordinates_ PPCPROMETHEUSSETCOORDINATES
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pcprometheussetcoordinates_ ppcprometheussetcoordinates
#else
#define pcprometheussetcoordinates_ ppcprometheussetcoordinates_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pcprometheussetcoordinates_ PCPROMETHEUSSETCOORDINATES
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pcprometheussetcoordinates_ pcprometheussetcoordinates
#endif
#endif



/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL   pcprometheussetcoordinates_(PC pc,PetscReal *coords, int *__ierr ){
*__ierr = PCPrometheusSetCoordinates(
	(PC)PetscToPointer((pc) ),coords);
}
#if defined(__cplusplus)
}
#endif
