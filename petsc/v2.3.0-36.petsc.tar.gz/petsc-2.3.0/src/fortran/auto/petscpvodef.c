#include "petsc.h"
#include "petscfix.h"
/* petscpvode.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "petscts.h"
#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define tspvodesettype_ PTSPVODESETTYPE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define tspvodesettype_ ptspvodesettype
#else
#define tspvodesettype_ ptspvodesettype_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define tspvodesettype_ TSPVODESETTYPE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define tspvodesettype_ tspvodesettype
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define tspvodesetgmresrestart_ PTSPVODESETGMRESRESTART
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define tspvodesetgmresrestart_ ptspvodesetgmresrestart
#else
#define tspvodesetgmresrestart_ ptspvodesetgmresrestart_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define tspvodesetgmresrestart_ TSPVODESETGMRESRESTART
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define tspvodesetgmresrestart_ tspvodesetgmresrestart
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define tspvodesetlineartolerance_ PTSPVODESETLINEARTOLERANCE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define tspvodesetlineartolerance_ ptspvodesetlineartolerance
#else
#define tspvodesetlineartolerance_ ptspvodesetlineartolerance_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define tspvodesetlineartolerance_ TSPVODESETLINEARTOLERANCE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define tspvodesetlineartolerance_ tspvodesetlineartolerance
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define tspvodesetgramschmidttype_ PTSPVODESETGRAMSCHMIDTTYPE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define tspvodesetgramschmidttype_ ptspvodesetgramschmidttype
#else
#define tspvodesetgramschmidttype_ ptspvodesetgramschmidttype_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define tspvodesetgramschmidttype_ TSPVODESETGRAMSCHMIDTTYPE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define tspvodesetgramschmidttype_ tspvodesetgramschmidttype
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define tspvodesettolerance_ PTSPVODESETTOLERANCE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define tspvodesettolerance_ ptspvodesettolerance
#else
#define tspvodesettolerance_ ptspvodesettolerance_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define tspvodesettolerance_ TSPVODESETTOLERANCE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define tspvodesettolerance_ tspvodesettolerance
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define tspvodegetpc_ PTSPVODEGETPC
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define tspvodegetpc_ ptspvodegetpc
#else
#define tspvodegetpc_ ptspvodegetpc_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define tspvodegetpc_ TSPVODEGETPC
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define tspvodegetpc_ tspvodegetpc
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define tspvodesetexactfinaltime_ PTSPVODESETEXACTFINALTIME
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define tspvodesetexactfinaltime_ ptspvodesetexactfinaltime
#else
#define tspvodesetexactfinaltime_ ptspvodesetexactfinaltime_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define tspvodesetexactfinaltime_ TSPVODESETEXACTFINALTIME
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define tspvodesetexactfinaltime_ tspvodesetexactfinaltime
#endif
#endif



/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL   tspvodesettype_(TS ts,TSPVodeType *type, int *__ierr ){
*__ierr = TSPVodeSetType(
	(TS)PetscToPointer((ts) ),*type);
}
void PETSC_STDCALL   tspvodesetgmresrestart_(TS ts,int *restart, int *__ierr ){
*__ierr = TSPVodeSetGMRESRestart(
	(TS)PetscToPointer((ts) ),*restart);
}
void PETSC_STDCALL   tspvodesetlineartolerance_(TS ts,double *tol, int *__ierr ){
*__ierr = TSPVodeSetLinearTolerance(
	(TS)PetscToPointer((ts) ),*tol);
}
void PETSC_STDCALL   tspvodesetgramschmidttype_(TS ts,TSPVodeGramSchmidtType *type, int *__ierr ){
*__ierr = TSPVodeSetGramSchmidtType(
	(TS)PetscToPointer((ts) ),*type);
}
void PETSC_STDCALL   tspvodesettolerance_(TS ts,double *aabs,double *rel, int *__ierr ){
*__ierr = TSPVodeSetTolerance(
	(TS)PetscToPointer((ts) ),*aabs,*rel);
}
void PETSC_STDCALL   tspvodegetpc_(TS ts,PC *pc, int *__ierr ){
*__ierr = TSPVodeGetPC(
	(TS)PetscToPointer((ts) ),pc);
}
void PETSC_STDCALL   tspvodesetexactfinaltime_(TS ts,PetscTruth *ft, int *__ierr ){
*__ierr = TSPVodeSetExactFinalTime(
	(TS)PetscToPointer((ts) ),*ft);
}
#if defined(__cplusplus)
}
#endif
