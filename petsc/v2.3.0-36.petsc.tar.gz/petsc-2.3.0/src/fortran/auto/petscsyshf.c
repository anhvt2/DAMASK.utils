#include "petsc.h"
#include "petscfix.h"
/* petscsys.h */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define insert_values_ PINSERT_VALUES
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define insert_values_ pinsert_values__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define insert_values_ pinsert_values
#else
#define insert_values_ pinsert_values_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define insert_values_ INSERT_VALUES
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define insert_values_ insert_values__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define insert_values_ insert_values
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define add_values_ PADD_VALUES
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define add_values_ padd_values__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define add_values_ padd_values
#else
#define add_values_ padd_values_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define add_values_ ADD_VALUES
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define add_values_ add_values__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define add_values_ add_values
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define max_values_ PMAX_VALUES
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define max_values_ pmax_values__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define max_values_ pmax_values
#else
#define max_values_ pmax_values_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define max_values_ MAX_VALUES
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define max_values_ max_values__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define max_values_ max_values
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define scatter_forward_ PSCATTER_FORWARD
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define scatter_forward_ pscatter_forward__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define scatter_forward_ pscatter_forward
#else
#define scatter_forward_ pscatter_forward_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define scatter_forward_ SCATTER_FORWARD
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define scatter_forward_ scatter_forward__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define scatter_forward_ scatter_forward
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define scatter_reverse_ PSCATTER_REVERSE
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define scatter_reverse_ pscatter_reverse__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define scatter_reverse_ pscatter_reverse
#else
#define scatter_reverse_ pscatter_reverse_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define scatter_reverse_ SCATTER_REVERSE
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define scatter_reverse_ scatter_reverse__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define scatter_reverse_ scatter_reverse
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define scatter_forward_local_ PSCATTER_FORWARD_LOCAL
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define scatter_forward_local_ pscatter_forward_local__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define scatter_forward_local_ pscatter_forward_local
#else
#define scatter_forward_local_ pscatter_forward_local_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define scatter_forward_local_ SCATTER_FORWARD_LOCAL
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define scatter_forward_local_ scatter_forward_local__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define scatter_forward_local_ scatter_forward_local
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define scatter_reverse_local_ PSCATTER_REVERSE_LOCAL
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define scatter_reverse_local_ pscatter_reverse_local__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define scatter_reverse_local_ pscatter_reverse_local
#else
#define scatter_reverse_local_ pscatter_reverse_local_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define scatter_reverse_local_ SCATTER_REVERSE_LOCAL
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define scatter_reverse_local_ scatter_reverse_local__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define scatter_reverse_local_ scatter_reverse_local
#endif
#endif



/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
#if defined(__cplusplus)
}
#endif
