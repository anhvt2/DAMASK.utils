#include "petsc.h"
#include "petscfix.h"
/* petscviewer.h */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsc_file_rdonly_ PPETSC_FILE_RDONLY
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define petsc_file_rdonly_ ppetsc_file_rdonly__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define petsc_file_rdonly_ ppetsc_file_rdonly
#else
#define petsc_file_rdonly_ ppetsc_file_rdonly_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsc_file_rdonly_ PETSC_FILE_RDONLY
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define petsc_file_rdonly_ petsc_file_rdonly__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define petsc_file_rdonly_ petsc_file_rdonly
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsc_file_wronly_ PPETSC_FILE_WRONLY
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define petsc_file_wronly_ ppetsc_file_wronly__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define petsc_file_wronly_ ppetsc_file_wronly
#else
#define petsc_file_wronly_ ppetsc_file_wronly_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsc_file_wronly_ PETSC_FILE_WRONLY
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define petsc_file_wronly_ petsc_file_wronly__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define petsc_file_wronly_ petsc_file_wronly
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsc_file_create_ PPETSC_FILE_CREATE
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define petsc_file_create_ ppetsc_file_create__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define petsc_file_create_ ppetsc_file_create
#else
#define petsc_file_create_ ppetsc_file_create_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsc_file_create_ PETSC_FILE_CREATE
#elif defined(FORTRANDOUBLEUNDERSCORE)
#define petsc_file_create_ petsc_file_create__
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
#define petsc_file_create_ petsc_file_create
#endif
#endif



/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
#if defined(__cplusplus)
}
#endif
