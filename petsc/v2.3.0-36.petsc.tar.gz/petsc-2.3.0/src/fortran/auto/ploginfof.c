#include "petsc.h"
#include "petscfix.h"
/* ploginfo.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "petsc.h"
#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscloginfodeactivateclass_ PPETSCLOGINFODEACTIVATECLASS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscloginfodeactivateclass_ ppetscloginfodeactivateclass
#else
#define petscloginfodeactivateclass_ ppetscloginfodeactivateclass_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscloginfodeactivateclass_ PETSCLOGINFODEACTIVATECLASS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscloginfodeactivateclass_ petscloginfodeactivateclass
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscloginfoactivateclass_ PPETSCLOGINFOACTIVATECLASS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscloginfoactivateclass_ ppetscloginfoactivateclass
#else
#define petscloginfoactivateclass_ ppetscloginfoactivateclass_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscloginfoactivateclass_ PETSCLOGINFOACTIVATECLASS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscloginfoactivateclass_ petscloginfoactivateclass
#endif
#endif



/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL   petscloginfodeactivateclass_(int *objclass, int *__ierr ){
*__ierr = PetscLogInfoDeactivateClass(*objclass);
}
void PETSC_STDCALL   petscloginfoactivateclass_(int *objclass, int *__ierr ){
*__ierr = PetscLogInfoActivateClass(*objclass);
}
#if defined(__cplusplus)
}
#endif
