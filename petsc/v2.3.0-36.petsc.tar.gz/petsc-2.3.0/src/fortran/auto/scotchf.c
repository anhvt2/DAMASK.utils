#include "petsc.h"
#include "petscfix.h"
/* scotch.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "petscmat.h"
#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matpartitioningscotchsetglobal_ PMATPARTITIONINGSCOTCHSETGLOBAL
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matpartitioningscotchsetglobal_ pmatpartitioningscotchsetglobal
#else
#define matpartitioningscotchsetglobal_ pmatpartitioningscotchsetglobal_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matpartitioningscotchsetglobal_ MATPARTITIONINGSCOTCHSETGLOBAL
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matpartitioningscotchsetglobal_ matpartitioningscotchsetglobal
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matpartitioningscotchsetcoarselevel_ PMATPARTITIONINGSCOTCHSETCOARSELEVEL
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matpartitioningscotchsetcoarselevel_ pmatpartitioningscotchsetcoarselevel
#else
#define matpartitioningscotchsetcoarselevel_ pmatpartitioningscotchsetcoarselevel_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matpartitioningscotchsetcoarselevel_ MATPARTITIONINGSCOTCHSETCOARSELEVEL
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matpartitioningscotchsetcoarselevel_ matpartitioningscotchsetcoarselevel
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matpartitioningscotchsetlocal_ PMATPARTITIONINGSCOTCHSETLOCAL
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matpartitioningscotchsetlocal_ pmatpartitioningscotchsetlocal
#else
#define matpartitioningscotchsetlocal_ pmatpartitioningscotchsetlocal_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matpartitioningscotchsetlocal_ MATPARTITIONINGSCOTCHSETLOCAL
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matpartitioningscotchsetlocal_ matpartitioningscotchsetlocal
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matpartitioningscotchsetmultilevel_ PMATPARTITIONINGSCOTCHSETMULTILEVEL
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matpartitioningscotchsetmultilevel_ pmatpartitioningscotchsetmultilevel
#else
#define matpartitioningscotchsetmultilevel_ pmatpartitioningscotchsetmultilevel_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matpartitioningscotchsetmultilevel_ MATPARTITIONINGSCOTCHSETMULTILEVEL
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matpartitioningscotchsetmultilevel_ matpartitioningscotchsetmultilevel
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matpartitioningscotchsetmapping_ PMATPARTITIONINGSCOTCHSETMAPPING
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matpartitioningscotchsetmapping_ pmatpartitioningscotchsetmapping
#else
#define matpartitioningscotchsetmapping_ pmatpartitioningscotchsetmapping_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matpartitioningscotchsetmapping_ MATPARTITIONINGSCOTCHSETMAPPING
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matpartitioningscotchsetmapping_ matpartitioningscotchsetmapping
#endif
#endif



/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL   matpartitioningscotchsetglobal_(MatPartitioning part,
    MPScotchGlobalType *global, int *__ierr ){
*__ierr = MatPartitioningScotchSetGlobal(
	(MatPartitioning)PetscToPointer((part) ),*global);
}
void PETSC_STDCALL   matpartitioningscotchsetcoarselevel_(MatPartitioning part,PetscReal *level, int *__ierr ){
*__ierr = MatPartitioningScotchSetCoarseLevel(
	(MatPartitioning)PetscToPointer((part) ),*level);
}
void PETSC_STDCALL   matpartitioningscotchsetlocal_(MatPartitioning part,MPScotchLocalType *local, int *__ierr ){
*__ierr = MatPartitioningScotchSetLocal(
	(MatPartitioning)PetscToPointer((part) ),*local);
}
void PETSC_STDCALL   matpartitioningscotchsetmultilevel_(MatPartitioning part, int *__ierr ){
*__ierr = MatPartitioningScotchSetMultilevel(
	(MatPartitioning)PetscToPointer((part) ));
}
void PETSC_STDCALL   matpartitioningscotchsetmapping_(MatPartitioning part, int *__ierr ){
*__ierr = MatPartitioningScotchSetMapping(
	(MatPartitioning)PetscToPointer((part) ));
}
#if defined(__cplusplus)
}
#endif
