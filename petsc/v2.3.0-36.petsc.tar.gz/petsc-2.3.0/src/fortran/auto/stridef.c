#include "petsc.h"
#include "petscfix.h"
/* stride.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "petscis.h"
#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define isstridegetinfo_ PISSTRIDEGETINFO
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define isstridegetinfo_ pisstridegetinfo
#else
#define isstridegetinfo_ pisstridegetinfo_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define isstridegetinfo_ ISSTRIDEGETINFO
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define isstridegetinfo_ isstridegetinfo
#endif
#endif



/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL   isstridegetinfo_(IS is,PetscInt *first,PetscInt *step, int *__ierr ){
*__ierr = ISStrideGetInfo(
	(IS)PetscToPointer((is) ),first,step);
}
#if defined(__cplusplus)
}
#endif
