#include "petsc.h"
#include "petscfix.h"
/* vscat.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "petscvec.h"
#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define vecscatterpostrecvs_ PVECSCATTERPOSTRECVS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define vecscatterpostrecvs_ pvecscatterpostrecvs
#else
#define vecscatterpostrecvs_ pvecscatterpostrecvs_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define vecscatterpostrecvs_ VECSCATTERPOSTRECVS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define vecscatterpostrecvs_ vecscatterpostrecvs
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define vecscattergetmerged_ PVECSCATTERGETMERGED
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define vecscattergetmerged_ pvecscattergetmerged
#else
#define vecscattergetmerged_ pvecscattergetmerged_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define vecscattergetmerged_ VECSCATTERGETMERGED
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define vecscattergetmerged_ vecscattergetmerged
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define vecscatterbegin_ PVECSCATTERBEGIN
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define vecscatterbegin_ pvecscatterbegin
#else
#define vecscatterbegin_ pvecscatterbegin_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define vecscatterbegin_ VECSCATTERBEGIN
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define vecscatterbegin_ vecscatterbegin
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define vecscatterend_ PVECSCATTEREND
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define vecscatterend_ pvecscatterend
#else
#define vecscatterend_ pvecscatterend_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define vecscatterend_ VECSCATTEREND
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define vecscatterend_ vecscatterend
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define vecscatterview_ PVECSCATTERVIEW
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define vecscatterview_ pvecscatterview
#else
#define vecscatterview_ pvecscatterview_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define vecscatterview_ VECSCATTERVIEW
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define vecscatterview_ vecscatterview
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define vecscatterremap_ PVECSCATTERREMAP
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define vecscatterremap_ pvecscatterremap
#else
#define vecscatterremap_ pvecscatterremap_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define vecscatterremap_ VECSCATTERREMAP
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define vecscatterremap_ vecscatterremap
#endif
#endif



/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL   vecscatterpostrecvs_(Vec x,Vec y,InsertMode *addv,ScatterMode *mode,VecScatter inctx, int *__ierr ){
*__ierr = VecScatterPostRecvs(
	(Vec)PetscToPointer((x) ),
	(Vec)PetscToPointer((y) ),*addv,*mode,
	(VecScatter)PetscToPointer((inctx) ));
}
void PETSC_STDCALL   vecscattergetmerged_(VecScatter ctx,PetscTruth *flg, int *__ierr ){
*__ierr = VecScatterGetMerged(
	(VecScatter)PetscToPointer((ctx) ),flg);
}
void PETSC_STDCALL   vecscatterbegin_(Vec x,Vec y,InsertMode *addv,ScatterMode *mode,VecScatter inctx, int *__ierr ){
*__ierr = VecScatterBegin(
	(Vec)PetscToPointer((x) ),
	(Vec)PetscToPointer((y) ),*addv,*mode,
	(VecScatter)PetscToPointer((inctx) ));
}
void PETSC_STDCALL   vecscatterend_(Vec x,Vec y,InsertMode *addv,ScatterMode *mode,VecScatter ctx, int *__ierr ){
*__ierr = VecScatterEnd(
	(Vec)PetscToPointer((x) ),
	(Vec)PetscToPointer((y) ),*addv,*mode,
	(VecScatter)PetscToPointer((ctx) ));
}
void PETSC_STDCALL   vecscatterview_(VecScatter ctx,PetscViewer viewer, int *__ierr ){
*__ierr = VecScatterView(
	(VecScatter)PetscToPointer((ctx) ),
	(PetscViewer)PetscToPointer((viewer) ));
}
void PETSC_STDCALL   vecscatterremap_(VecScatter scat,PetscInt *rto,PetscInt *rfrom, int *__ierr ){
*__ierr = VecScatterRemap(
	(VecScatter)PetscToPointer((scat) ),rto,rfrom);
}
#if defined(__cplusplus)
}
#endif
