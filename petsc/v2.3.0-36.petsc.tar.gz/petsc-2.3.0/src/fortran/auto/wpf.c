#include "petsc.h"
#include "petscfix.h"
/* wp.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "petscsnes.h"
#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matsnesmfwpsetcomputenorma_ PMATSNESMFWPSETCOMPUTENORMA
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matsnesmfwpsetcomputenorma_ pmatsnesmfwpsetcomputenorma
#else
#define matsnesmfwpsetcomputenorma_ pmatsnesmfwpsetcomputenorma_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matsnesmfwpsetcomputenorma_ MATSNESMFWPSETCOMPUTENORMA
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matsnesmfwpsetcomputenorma_ matsnesmfwpsetcomputenorma
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matsnesmfwpsetcomputenormu_ PMATSNESMFWPSETCOMPUTENORMU
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matsnesmfwpsetcomputenormu_ pmatsnesmfwpsetcomputenormu
#else
#define matsnesmfwpsetcomputenormu_ pmatsnesmfwpsetcomputenormu_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matsnesmfwpsetcomputenormu_ MATSNESMFWPSETCOMPUTENORMU
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matsnesmfwpsetcomputenormu_ matsnesmfwpsetcomputenormu
#endif
#endif



/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL   matsnesmfwpsetcomputenorma_(Mat A,PetscTruth *flag, int *__ierr ){
*__ierr = MatSNESMFWPSetComputeNormA(
	(Mat)PetscToPointer((A) ),*flag);
}
void PETSC_STDCALL   matsnesmfwpsetcomputenormu_(Mat A,PetscTruth *flag, int *__ierr ){
*__ierr = MatSNESMFWPSetComputeNormU(
	(Mat)PetscToPointer((A) ),*flag);
}
#if defined(__cplusplus)
}
#endif
