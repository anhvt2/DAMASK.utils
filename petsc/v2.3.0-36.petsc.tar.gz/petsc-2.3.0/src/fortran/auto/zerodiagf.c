#include "petsc.h"
#include "petscfix.h"
/* zerodiag.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "petscmat.h"
#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matreorderfornonzerodiagonal_ PMATREORDERFORNONZERODIAGONAL
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matreorderfornonzerodiagonal_ pmatreorderfornonzerodiagonal
#else
#define matreorderfornonzerodiagonal_ pmatreorderfornonzerodiagonal_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matreorderfornonzerodiagonal_ MATREORDERFORNONZERODIAGONAL
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matreorderfornonzerodiagonal_ matreorderfornonzerodiagonal
#endif
#endif



/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL   matreorderfornonzerodiagonal_(Mat mat,PetscReal *abstol,IS ris,IS cis, int *__ierr ){
*__ierr = MatReorderForNonzeroDiagonal(
	(Mat)PetscToPointer((mat) ),*abstol,
	(IS)PetscToPointer((ris) ),
	(IS)PetscToPointer((cis) ));
}
#if defined(__cplusplus)
}
#endif
