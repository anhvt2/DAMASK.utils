% --------------------------------------------
% errors 
% --------------------------------------------

'SparseGKit:WrongInput' %#ok<*NOPTS>
'SparseGKit:NoOpenPar'
'SparseGKit:SetNotSorted'
'SparseGKit:OutOfTable'
'SparseGKit:ToBeCoded'
'SparseGKit:FailedSanityChk'

% --------------------------------------------
% warnings
% --------------------------------------------

'SparseGKit:GridsAreEqual'
'SparseGKit:deprecated'
'SparseGKit:TolNotEnough'
'SparseGKit:uint16'
'SparseGKit:double'
'SparseGKit:KpnNonTab'
'SparseGKit:IgnoredInput' %#ok<*NOPTS>

