% --------------------------------------------
% errors 
% --------------------------------------------

'SparseGKit:WrongInput' %#ok<*NOPTS>
'SparseGKit:NoOpenPar'
'SparseGKit:SetNotSorted'
'SparseGKit:OutOfTable'
'SparseGKit:ToBeCoded'
'SparseGKit:FailedSanityChk'
'SparseGKit:RenamedFunction'

% --------------------------------------------
% warnings
% --------------------------------------------

'SparseGKit:GridsAreEqual'
'SparseGKit:deprecated'
'SparseGKit:TolNotEnough'
'SparseGKit:uint16'
'SparseGKit:double'
'SparseGKit:GKNonTab'
'SparseGKit:IgnoredInput' %#ok<*NOPTS>
'SparseGKit:InconsistentInput'
