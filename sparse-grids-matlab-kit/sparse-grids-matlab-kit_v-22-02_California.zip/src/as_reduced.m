function S = as_reduced(pts_list,wgs_list) %#ok<INUSD,STOUT>

error('SparseGKit:RenamedFunction','AS_REDUCED has been renamed to ASREDUCED for naming consistency')