function h= plot_grid(S,dims,varargin) %#ok<INUSD,STOUT>

error('SparseGKit:RenamedFunction','PLOT_GRID has been renamed to PLOT_SPARSE_GRID for naming consistency')