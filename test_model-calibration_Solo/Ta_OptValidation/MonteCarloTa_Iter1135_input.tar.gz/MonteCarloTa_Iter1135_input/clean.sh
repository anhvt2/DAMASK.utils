#!/bin/bash

rm -rfv $(ls -1dv */)
